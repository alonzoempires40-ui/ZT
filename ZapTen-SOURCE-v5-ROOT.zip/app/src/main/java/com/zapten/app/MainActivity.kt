package com.zapten.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.CookieManager
import android.webkit.ConsoleMessage
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.net.http.SslError
import androidx.compose.ui.text.font.FontFamily
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

// ---- palette (matches the StreamLine project so the setup screen feels the same) ----
private val Ink = Color(0xFF0B0E16)
private val Panel = Color(0xFF141927)
private val Line = Color(0xFF262E45)
private val TextCol = Color(0xFFEAEDF5)
private val Muted = Color(0xFF8A93AB)
private val Amber = Color(0xFFF5B638)

class MainActivity : ComponentActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private sealed class Screen {
    object Setup : Screen()
    object Portal : Screen()
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    // Go straight to the portal if it is already set up; otherwise show first-run setup.
    var screen by remember {
        mutableStateOf<Screen>(
            if (Prefs.setupDone(ctx) && Prefs.url(ctx).isNotBlank()) Screen.Portal else Screen.Setup
        )
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Amber, background = Ink, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Ink)) {
            when (screen) {
                Screen.Setup -> SetupScreen(onOpen = { screen = Screen.Portal })
                Screen.Portal -> PortalScreen(onSettings = { screen = Screen.Setup })
            }
        }
    }
}

/** First-run / settings: the portal address(es) and this box's MAC to give the provider. */
@Composable
private fun SetupScreen(onOpen: () -> Unit) {
    val ctx = LocalContext.current
    var active by remember { mutableStateOf(Prefs.activePortal(ctx)) }
    var url1 by remember { mutableStateOf(Prefs.url(ctx, 1)) }
    var url2 by remember { mutableStateOf(Prefs.url(ctx, 2)) }
    val mac = remember(active) { Prefs.mac(ctx, active) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zap", color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Ten", color = Amber, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(4.dp))
        Text("Set up your portal, like a set-top box.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))

        // Portal selector
        Text("PORTAL", color = Amber, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PortalChip("Portal 1", active == 1) { active = 1; Prefs.saveActivePortal(ctx, 1) }
            PortalChip("Portal 2", active == 2) { active = 2; Prefs.saveActivePortal(ctx, 2) }
        }
        Spacer(Modifier.height(20.dp))

        Field("Portal $active address", if (active == 1) url1 else url2,
            placeholder = "subdomain.domain.com or …/stalker_portal") { v ->
            if (active == 1) url1 = v else url2 = v
        }
        Spacer(Modifier.height(16.dp))

        // MAC to give the provider
        Column(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(16.dp)
        ) {
            Text("THIS BOX'S MAC — give it to your provider", color = Amber, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(mac, color = TextCol, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Portal $active uses this MAC. Portal 1 and Portal 2 each have their own.",
                color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                Prefs.saveUrl(ctx, 1, url1)
                Prefs.saveUrl(ctx, 2, url2)
                Prefs.saveActivePortal(ctx, active)
                if (Prefs.url(ctx, active).isNotBlank()) {
                    Prefs.markSetupDone(ctx)
                    onOpen()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304)),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Open portal $active", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        Spacer(Modifier.height(16.dp))
        Text(
            "ZapTen opens your provider's own portal page and signs in like a MAG box. " +
                "Add this MAC on the portal first.",
            color = Muted, fontSize = 12.sp
        )
    }
}

@Composable
private fun PortalChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color(0xFF1A1304) else TextCol,
        fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .background(if (selected) Amber else Panel, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 9.dp)
    )
}

@Composable
private fun Field(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = true,
            placeholder = { Text(placeholder, color = Muted, fontSize = 13.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Amber, unfocusedBorderColor = Line,
                focusedTextColor = TextCol, unfocusedTextColor = TextCol,
                cursorColor = Amber
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Builds the portal client-page URL from the address the user typed. Like StreamLine, only the
 *  domain is needed: no scheme → https://, no path → /stalker_portal, then /c/. So "domain" opens
 *  https://domain/stalker_portal/c/. A typed path (or a full …/stalker_portal/c/ address) is kept. */
private fun portalPageUrl(input: String): String {
    var s = input.trim()
    if (s.isEmpty()) return ""
    if (!s.startsWith("http://") && !s.startsWith("https://")) s = "https://$s"
    s = s.trimEnd('/')
    s = s.removeSuffix("/c").trimEnd('/')
    val path = s.substringAfter("://").substringAfter('/', "")
    if (path.isEmpty()) s = "$s/stalker_portal"
    return "$s/c/"
}

/** The portal's own MAG interface, in a WebView, with the set-top-box API provided underneath.
 *  Build 3: a logger. Every page load, HTTP/SSL error, console message, portal request and box-API
 *  call is recorded (DebugLog) and shown in the on-screen Log panel. Small always-visible buttons
 *  (Settings / Reload / Log) at the top-right mean a black screen is never a dead end. */
@Composable
private fun PortalScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val portal = remember { Prefs.activePortal(ctx) }
    val pageUrl = remember { portalPageUrl(Prefs.url(ctx, portal)) }
    var webRef by remember { mutableStateOf<WebView?>(null) }
    var lastBack by remember { mutableStateOf(0L) }
    var showLog by remember { mutableStateOf(false) }

    // BACK: first press is sent to the portal (like a box's Back key); a quick second press opens
    // settings, so the user is never trapped. With the Log open, BACK closes it.
    BackHandler {
        if (showLog) { showLog = false; return@BackHandler }
        val now = System.currentTimeMillis()
        if (now - lastBack < 1500) { onSettings() }
        else {
            lastBack = now
            webRef?.evaluateJavascript(
                "(function(){['keydown'].forEach(function(t){[8,27].forEach(function(k){" +
                    "var e=new KeyboardEvent(t,{bubbles:true});" +
                    "Object.defineProperty(e,'keyCode',{get:function(){return k}});" +
                    "Object.defineProperty(e,'which',{get:function(){return k}});" +
                    "document.dispatchEvent(e);});});})();", null
            )
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                CookieManager.getInstance().setAcceptCookie(true)
                DebugLog.add("open portal " + portal + ": " + pageUrl)
                DebugLog.add("MAC " + Prefs.mac(ctx, portal) + "  serial " + Prefs.serial(ctx, portal))
                WebView(c).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    with(settings) {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        userAgentString = StbBridge.userAgent()
                        @Suppress("DEPRECATION")
                        mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        setSupportMultipleWindows(false)
                    }
                    val web = this
                    val rebootTimes = java.util.ArrayDeque<Long>()
                    addJavascriptInterface(StbBridge(c.applicationContext, portal, onReboot = {
                        // called from the JS-bridge thread; the WebView must be touched on the main thread
                        web.post {
                            val now = System.currentTimeMillis()
                            while (rebootTimes.isNotEmpty() && now - rebootTimes.peekFirst()!! > 60_000) rebootTimes.pollFirst()
                            rebootTimes.addLast(now)
                            if (rebootTimes.size > 3) DebugLog.add("--- reboot asked " + rebootTimes.size + "x in a minute: STOPPED (loop) — see the lines above ---")
                            else { DebugLog.add("--- reboot (reload) ---"); web.loadUrl(pageUrl) }
                        }
                    }), "ZTBridge")
                    // Provide window.gSTB (and the other box globals) BEFORE the portal's scripts run.
                    val js = StbBridge.injectionJs()
                    val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
                    DebugLog.add("document-start injection supported: " + docStart)
                    if (docStart) WebViewCompat.addDocumentStartJavaScript(this, js, setOf("*"))
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                            DebugLog.add("console[" + m.messageLevel() + "] " + m.message() + "  (" + m.sourceId().substringAfterLast('/') + ":" + m.lineNumber() + ")")
                            return true
                        }
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            DebugLog.add("page started: " + url)
                            if (!docStart) view.evaluateJavascript(js, null)   // fallback injection
                        }
                        override fun onPageFinished(view: WebView, url: String?) {
                            super.onPageFinished(view, url)
                            DebugLog.add("page finished: " + url)
                            view.evaluateJavascript(
                                "(function(){return 'gSTB=' + (typeof gSTB) + ' stb=' + (typeof stb) + ' title=' + document.title + ' bodyLen=' + (document.body ? document.body.innerHTML.length : -1);})()"
                            ) { r -> DebugLog.add("page state: " + r) }
                        }
                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            super.onReceivedError(view, request, error)
                            DebugLog.add((if (request.isForMainFrame) "MAIN " else "") + "load error " + error.errorCode + " " + error.description + " : " + request.url)
                        }
                        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                            super.onReceivedHttpError(view, request, response)
                            DebugLog.add((if (request.isForMainFrame) "MAIN " else "") + "HTTP " + response.statusCode + " " + response.reasonPhrase + " : " + request.url)
                        }
                        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                            DebugLog.add("SSL error " + error.primaryError + " : " + error.url + "  (connection refused — certificate not trusted)")
                            handler.cancel()
                        }
                    }
                    webRef = this
                    if (pageUrl.isNotBlank()) loadUrl(pageUrl) else DebugLog.add("no portal address saved")
                }
            }
        )

        // Always-visible controls (top-right): never stuck on a black page.
        Row(
            Modifier.align(Alignment.TopEnd).padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SmallBtn("Settings") { onSettings() }
            SmallBtn("Reload") { DebugLog.add("--- reload ---"); webRef?.loadUrl(pageUrl) }
            SmallBtn(if (showLog) "Hide log" else "Log") { showLog = !showLog }
        }

        if (showLog) LogPanel(onClear = { DebugLog.clear() }, onCopy = {
            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("ZapTen log", DebugLog.dump()))
        })
    }
}

@Composable
private fun SmallBtn(label: String, onClick: () -> Unit) {
    Text(
        label, color = TextCol, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .background(Color(0xCC141927), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

/** The log: newest lines at the bottom, scrollable; Copy puts the whole log on the clipboard. */
@Composable
private fun LogPanel(onClear: () -> Unit, onCopy: () -> Unit) {
    val lines = DebugLog.lines
    val scroll = rememberScrollState()
    LaunchedEffect(lines.size) { scroll.scrollTo(scroll.maxValue) }
    Column(
        Modifier.fillMaxWidth().fillMaxHeight(0.6f).padding(top = 44.dp, start = 10.dp, end = 10.dp)
            .background(Color(0xE60B0E16), RoundedCornerShape(10.dp)).padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ZapTen log  ·  " + lines.size + " lines", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            SmallBtn("Copy") { onCopy() }
            Spacer(Modifier.width(6.dp))
            SmallBtn("Clear") { onClear() }
        }
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
            for (l in lines) Text(l, color = TextCol, fontSize = 11.sp, lineHeight = 14.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
