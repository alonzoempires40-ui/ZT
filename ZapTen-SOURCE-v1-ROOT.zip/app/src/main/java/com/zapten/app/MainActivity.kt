package com.zapten.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.CookieManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

// ---- palette (matches the StreamLine project so the setup screen feels the same) ----
private val Ink = Color(0xFF0B0E16)
private val Panel = Color(0xFF141927)
private val Line = Color(0xFF262E45)
private val TextCol = Color(0xFFEAEDF5)
private val Muted = Color(0xFF8A93AB)
private val Amber = Color(0xFFF5B638)

class MainActivity : ComponentActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private sealed class Screen {
    object Setup : Screen()
    object Portal : Screen()
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    // Go straight to the portal if it is already set up; otherwise show first-run setup.
    var screen by remember {
        mutableStateOf<Screen>(
            if (Prefs.setupDone(ctx) && Prefs.url(ctx).isNotBlank()) Screen.Portal else Screen.Setup
        )
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Amber, background = Ink, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Ink)) {
            when (screen) {
                Screen.Setup -> SetupScreen(onOpen = { screen = Screen.Portal })
                Screen.Portal -> PortalScreen(onSettings = { screen = Screen.Setup })
            }
        }
    }
}

/** First-run / settings: the portal address(es) and this box's MAC to give the provider. */
@Composable
private fun SetupScreen(onOpen: () -> Unit) {
    val ctx = LocalContext.current
    var active by remember { mutableStateOf(Prefs.activePortal(ctx)) }
    var url1 by remember { mutableStateOf(Prefs.url(ctx, 1)) }
    var url2 by remember { mutableStateOf(Prefs.url(ctx, 2)) }
    val mac = remember(active) { Prefs.mac(ctx, active) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zap", color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Ten", color = Amber, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(4.dp))
        Text("Set up your portal, like a set-top box.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))

        // Portal selector
        Text("PORTAL", color = Amber, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PortalChip("Portal 1", active == 1) { active = 1; Prefs.saveActivePortal(ctx, 1) }
            PortalChip("Portal 2", active == 2) { active = 2; Prefs.saveActivePortal(ctx, 2) }
        }
        Spacer(Modifier.height(20.dp))

        Field("Portal $active address", if (active == 1) url1 else url2,
            placeholder = "subdomain.domain.com or …/stalker_portal") { v ->
            if (active == 1) url1 = v else url2 = v
        }
        Spacer(Modifier.height(16.dp))

        // MAC to give the provider
        Column(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(16.dp)
        ) {
            Text("THIS BOX'S MAC — give it to your provider", color = Amber, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(mac, color = TextCol, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Portal $active uses this MAC. Portal 1 and Portal 2 each have their own.",
                color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                Prefs.saveUrl(ctx, 1, url1)
                Prefs.saveUrl(ctx, 2, url2)
                Prefs.saveActivePortal(ctx, active)
                if (Prefs.url(ctx, active).isNotBlank()) {
                    Prefs.markSetupDone(ctx)
                    onOpen()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304)),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Open portal $active", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        Spacer(Modifier.height(16.dp))
        Text(
            "ZapTen opens your provider's own portal page and signs in like a MAG box. " +
                "Add this MAC on the portal first.",
            color = Muted, fontSize = 12.sp
        )
    }
}

@Composable
private fun PortalChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color(0xFF1A1304) else TextCol,
        fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .background(if (selected) Amber else Panel, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 9.dp)
    )
}

@Composable
private fun Field(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = true,
            placeholder = { Text(placeholder, color = Muted, fontSize = 13.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Amber, unfocusedBorderColor = Line,
                focusedTextColor = TextCol, unfocusedTextColor = TextCol,
                cursorColor = Amber
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Builds the portal client-page URL from the address the user typed (append /c/). */
private fun portalPageUrl(input: String): String {
    var s = input.trim()
    if (s.isEmpty()) return ""
    if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
    s = s.trimEnd('/')
    s = s.removeSuffix("/c").trimEnd('/')
    return "$s/c/"
}

/** The portal's own MAG interface, in a WebView, with the set-top-box API provided underneath. */
@Composable
private fun PortalScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val portal = remember { Prefs.activePortal(ctx) }
    val pageUrl = remember { portalPageUrl(Prefs.url(ctx, portal)) }
    var webRef by remember { mutableStateOf<WebView?>(null) }
    var lastBack by remember { mutableStateOf(0L) }

    // BACK: first press is sent to the portal (like a box's Back key); a quick second press opens
    // settings, so the user is never trapped.
    BackHandler {
        val now = System.currentTimeMillis()
        if (now - lastBack < 1500) { onSettings() }
        else {
            lastBack = now
            webRef?.evaluateJavascript(
                "(function(){['keydown'].forEach(function(t){[8,27].forEach(function(k){" +
                    "var e=new KeyboardEvent(t,{bubbles:true});" +
                    "Object.defineProperty(e,'keyCode',{get:function(){return k}});" +
                    "Object.defineProperty(e,'which',{get:function(){return k}});" +
                    "document.dispatchEvent(e);});});})();", null
            )
        }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            CookieManager.getInstance().setAcceptCookie(true)
            WebView(c).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(android.graphics.Color.BLACK)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                with(settings) {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    userAgentString = StbBridge.userAgent()
                    @Suppress("DEPRECATION")
                    mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    setSupportMultipleWindows(false)
                }
                addJavascriptInterface(StbBridge(c.applicationContext, portal), "ZTBridge")
                // Provide window.gSTB (and the other box globals) BEFORE the portal's scripts run.
                val js = StbBridge.injectionJs()
                if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    WebViewCompat.addDocumentStartJavaScript(this, js, setOf("*"))
                }
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                        // Fallback for devices without DOCUMENT_START_SCRIPT: inject as early as we can.
                        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                            view.evaluateJavascript(js, null)
                        }
                    }
                }
                webRef = this
                if (pageUrl.isNotBlank()) loadUrl(pageUrl)
            }
        }
    )
}
