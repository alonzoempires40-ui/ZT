package com.zapten.app

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * The set-top-box API, exposed to the portal's own c/ interface running in the WebView.
 *
 * A MAG box provides a native `gSTB` object; the portal's JavaScript calls it for the device
 * identity, the login crypto, device info and (later) the player. ZapTen provides the same object:
 * this class is injected as `ZTBridge`, and a small JS shim (injectionJs) builds `window.gSTB` and
 * the other box globals on top of it BEFORE the portal's scripts run. The portal then does the
 * handshake, get_profile and everything else itself, exactly as on a box.
 *
 * Build 1 covers identity + login + device info (enough for the box to authorise and show ONLINE).
 * The player methods (Play/Stop/…) are stubbed to no-ops here and wired to the three video engines
 * in build 2.
 *
 * Methods run on the WebView's JavaScript-bridge thread, not the UI thread.
 */
class StbBridge(private val appCtx: Context, private val portal: Int) {

    private val mac = Prefs.mac(appCtx, portal)
    private val serial = Prefs.serial(appCtx, portal)
    private val devId = Prefs.deviceId(appCtx, portal).ifBlank { BoxCrypto.macDeviceId(mac) }

    // ---- identity + login crypto (the portal's gSTB.GetUID / gSTB.GetHashVersion1 delegate here) ----

    /** GetUID() — the primary device id. A real box returns device_id == device_id2. */
    @JavascriptInterface fun deviceId(): String = devId

    /** GetUID(random) — the signature = Base64(HMAC-SHA256(key=random, data=device_id)) + "\n". */
    @JavascriptInterface fun sign(random: String): String = BoxCrypto.hmacB64(devId, random)

    /** GetHashVersion1(a, b) — used for hw_version_2 (metrics, random) and prehash (model, ver56). */
    @JavascriptInterface fun hv1(a: String, b: String): String = BoxCrypto.getHashVersion1(a, b)

    // ---- device info ----
    @JavascriptInterface fun mac(): String = mac
    @JavascriptInterface fun serial(): String = serial
    @JavascriptInterface fun model(): String = BoxCrypto.MODEL
    @JavascriptInterface fun hwVersion(): String = BoxCrypto.HW_VERSION
    @JavascriptInterface fun version(): String = "JS API version: 343; STB API version: 146; Player Engine version: 0x58c"

    /** RDir — the box's environment reader. The interface calls getenv/direct keys at start-up. */
    @JavascriptInterface
    fun rdir(arg: String): String {
        val a = arg.trim()
        if (a.startsWith("setenv")) return ""      // writes are accepted and ignored
        val key = if (a.startsWith("getenv ")) a.substring(7).trim() else a
        return when (key) {
            "language" -> "en"
            "timezone_conf" -> "Europe/London"
            "ntpurl" -> "pool.ntp.org"
            "mtdparts" ->
                // two banks (contains "RootFs2") → num_banks = 2, matching the proven config
                "nand:0x00000000@0x00000000(\"RootFs\"),0x00000000@0x00000000(\"RootFs2\")"
            "update_url" -> ""
            "vmode" -> ""
            "gmode" -> "720"
            "IPAddress" -> ""
            "MACAddress" -> mac
            "SerialNumber" -> serial
            "Model" -> BoxCrypto.MODEL
            "HardwareVersion" -> BoxCrypto.HW_VERSION
            "ImageVersion" -> BoxCrypto.IMAGE_VERSION
            "ImageDescription" -> BoxCrypto.IMAGE_DESCRIPTION
            "ImageDate" -> BoxCrypto.IMAGE_DATE
            else -> ""
        }
    }

    /** SaveUserData(file, data) / LoadUserData(file) — the box's small key/value store (access token). */
    @JavascriptInterface fun saveUserData(file: String, data: String) = Prefs.saveUserData(appCtx, file, data)
    @JavascriptInterface fun loadUserData(file: String): String = Prefs.userData(appCtx, file)

    companion object {
        /** The User-Agent the WebView must send so the portal's load.php sees a MAG254. */
        fun userAgent(): String = BoxCrypto.USER_AGENT

        /**
         * The JS injected at document start, before the portal's own scripts. It builds window.gSTB
         * (delegating identity/crypto/info to ZTBridge) plus empty box globals, so the MAG interface
         * finds the box API it expects. gSTB is wrapped in a Proxy so any box method we have not wired
         * yet (the player etc.) is a harmless no-op instead of a crash — until build 2 fills them in.
         */
        fun injectionJs(): String = """
(function(){
  if (window.__ztGstb) { return; }
  window.__ztGstb = true;
  var B = window.ZTBridge;

  // The real box methods ZapTen implements for build 1 (identity, login crypto, device info, store).
  var real = {
    // GetUID(): device_id ; GetUID(random): signature ; GetUID(x, y[, z]): device_id (device_id2)
    GetUID: function(){
      if (arguments.length === 0) { return B.deviceId(); }
      if (arguments.length === 1) { return B.sign(String(arguments[0])); }
      return B.deviceId();
    },
    GetHashVersion1: function(a, b){ return B.hv1(String(a == null ? '' : a), String(b == null ? '' : b)); },
    GetDeviceMacAddress: function(){ return B.mac(); },
    GetDeviceSerialNumber: function(){ return B.serial(); },
    GetDeviceModelExt: function(){ return B.model(); },
    GetDeviceVersionHardware: function(){ return B.hwVersion(); },
    GetHDMIConnectionState: function(){ return 1; },
    IsEmulator: function(){ return 0; },
    Version: function(){ return B.version(); },
    RDir: function(a){ return B.rdir(String(a == null ? '' : a)); },
    SaveUserData: function(file, data){ B.saveUserData(String(file), String(data == null ? '' : data)); return true; },
    LoadUserData: function(file){ return B.loadUserData(String(file)); },
    // start-up no-ops (present so calls do not throw; harmless on a WebView)
    Debug: function(){}, ExecAction: function(){}, StandBy: function(){}, StandByMode: function(){ return 0; },
    SetObjectCacheCapacities: function(){}, SetLedIndicatorMode: function(){}, SetLedIndicatorLevels: function(){},
    SetScreenSaverTime: function(){}, SetScreenSaverImplUrl: function(){}, SetScreenSaverInitAttr: function(){},
    SetSettingsInitAttr: function(){}, SetNetRcStatus: function(){}, ConfigNetRc: function(){},
    GetSystemPaths: function(){ return '{}'; }
  };

  // Wrap so any box method not listed above is a no-op (returns ''), and force the resize path to
  // use screen.height by making .prototype non-function.
  window.gSTB = new Proxy(real, {
    get: function(t, p){
      if (p === 'prototype') { return undefined; }
      if (p in t) { return t[p]; }
      if (typeof p === 'symbol') { return t[p]; }
      return function(){ return ''; };
    }
  });

  // Other box globals the interface checks for / links to. Empty no-op objects for build 1.
  function noop(){ return new Proxy({}, { get: function(t, p){
    if (p in t) { return t[p]; }
    if (typeof p === 'symbol') { return t[p]; }
    return function(){ return ''; };
  }}); }
  window.stbWebWindow       = noop();
  window.stbWindowMgr       = noop();
  window.stbStorage         = noop();
  window.stbUpdate          = noop();
  window.stbDownloadManager = noop();
  window.stbUPnP            = noop();
  window.dvbManager         = noop();
  window.pvrManager         = noop();
  window.timeShift          = noop();
  window.stbEvent           = {};   // the interface ASSIGNS handlers onto this (onPortalEvent = …)
  window.stbPlayerManager   = noop();
})();
""".trimIndent()
    }
}
