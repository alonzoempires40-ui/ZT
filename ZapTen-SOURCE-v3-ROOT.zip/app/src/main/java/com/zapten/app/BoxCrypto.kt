package com.zapten.app

/**
 * The set-top-box login maths. Ported BYTE-FOR-BYTE from the StreamLine project's StalkerClient
 * (the "EXACT StbEmu auth crypto" block), which is verified working against live Ministra portals.
 * ZapTen does not do the login itself — the portal's own c/ interface does, calling these through
 * the JavaScript bridge (gSTB.GetUID / gSTB.GetHashVersion1). Keeping the maths identical means the
 * values ZapTen produces match what the proven app produces for the same MAC + random.
 *
 * Verified derivations:
 *   device_id   = upperHex( SHA-256( MAC ) )              (macDeviceId) — the box-accurate default
 *   signature   = Base64( HMAC-SHA256(key=random, data=device_id) ) + "\n"   (ry.D)
 *   hw_version_2= GetHashVersion1( orderedMetricsJson, random )
 *   prehash     = GetHashVersion1( model, version[0..56) )
 */
object BoxCrypto {

    /** StbEmu's hardcoded salt used inside GetHashVersion1. */
    private const val STB_SALT = "dA0j6HpVFcMgNjUBDr0QhwTBIzLHDIrynuQy4XNJ"

    /** ry.Q: lowercase-hex SHA-1, ISO-8859-1 charset (StbEmu's exact impl). */
    private fun qSha1(s: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-1")
        val bytes = md.digest(s.toByteArray(Charsets.ISO_8859_1))
        return bytes.joinToString("") { ((it.toInt() and 0xFF) + 0x100).toString(16).substring(1) }
    }

    /** ry.C: lowercase-hex SHA-256, UTF-8 (StbEmu's exact impl). */
    private fun cSha256(s: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(s.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { ((it.toInt() and 0xFF) + 0x100).toString(16).substring(1) }
    }

    /** GetHashVersion1(d1,d2) = Q( Q( Q(d1) + SALT ) + d2 ). Used for hw_version_2 & prehash. */
    fun getHashVersion1(data1: String, data2: String = ""): String {
        val inner = qSha1(qSha1(data1) + STB_SALT)
        return qSha1(inner + data2)
    }

    /**
     * ry.D: Base64( HMAC-SHA256(key, data) ) using Base64 flag 0 = DEFAULT, which appends a trailing
     * '\n'. The newline is kept to byte-match StbEmu. Used for the signature: hmacB64(device_id, random).
     */
    fun hmacB64(data: String, key: String): String {
        return try {
            val mac = javax.crypto.Mac.getInstance("HmacSHA256")
            mac.init(javax.crypto.spec.SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
            android.util.Base64.encodeToString(
                mac.doFinal(data.toByteArray(Charsets.UTF_8)),
                android.util.Base64.DEFAULT
            )
        } catch (_: Exception) { "" }
    }

    /** StbEmu's MAC-based device_id: upperHex( SHA-256( mac ) ). MAC kept as-is (colons). */
    fun macDeviceId(mac: String): String = cSha256(mac).uppercase()

    /** The box serial, derived from the MAC: first 13 chars of upperHex( MD5( mac ) ).
     *  Deterministic, matching the proven StreamLine TV login service. */
    fun macSerial(mac: String): String {
        val md = java.security.MessageDigest.getInstance("MD5")
        val hex = md.digest(mac.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return hex.take(13).uppercase()
    }

    // ---- MAG254 box profile (BYTE-IDENTICAL to StreamLine's proven MAG254 config) ----
    const val MODEL = "MAG254"
    const val IMAGE_DESCRIPTION = "0.2.18-r23-pub-254"
    const val IMAGE_DATE = "Wed Aug 28 18:30:00 EEST 2019"
    const val IMAGE_VERSION = "218"
    const val HW_VERSION = "1.7-BD-00"

    /** The User-Agent a MAG254 sends. The portal's load.php matches this against stb_type. */
    const val USER_AGENT =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) " +
            "MAG254 stbapp ver: 4 rev: 2721 Safari/533.3"

    /** The composite version string the interface builds. Only its first 56 chars feed the prehash,
     *  so the PORTAL/API tail is cosmetic; this matches StreamLine's verStr to the character. */
    const val VERSION_STR =
        "ImageDescription: 0.2.18-r23-pub-254; ImageDate: Wed Aug 28 18:30:00 EEST 2019; " +
            "PORTAL version: 5.6.0; API Version: JS API version: 343; STB API version: 146; " +
            "Player Engine version: 0x58c"
}
