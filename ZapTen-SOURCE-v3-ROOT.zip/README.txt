ZapTen — build 1
================

WHAT IT IS
ZapTen is an Android TV / box app (package com.zapten.app) that behaves like a MAG set-top box:
it opens YOUR PROVIDER'S OWN portal page (stalker_portal/c/, the StreamLine-for-MAG interface)
full screen and signs in like a box, so the portal's own code does the login, channels, movies,
series, guide and settings. ZapTen itself has no media screens of its own — it provides the
set-top-box API (the identity and the login crypto) underneath the portal page.

This is build 1 of the series:
  - the name ZapTen and the new icon (app icon + Android TV banner);
  - a first-run setup screen: your portal address(es) + this box's MAC to give the provider;
  - the portal interface opening and LOGGING IN (handshake + two-step get_profile). The box
    appears ONLINE in the portal admin.
Build 2 adds video (live TV, movies, series play); build 3 adds the portal's extra windows, the
on-screen keyboard and standby. See VERSION.txt.

SEPARATE APP (your choice)
  - applicationId com.zapten.app — a NEW app, installs alongside StreamLine, does not replace it.
  - It makes its OWN MAC (one per portal), which you add on the portal like a MAG box.
  - StreamLine is untouched and stays at build 40.

HOW TO BUILD IT (its OWN repo — NOT OS-Small)
ZapTen is a second project. OS-Small is for StreamLine only, so ZapTen needs its own private
GitHub repo with the same Actions workflow:
  1. Make a new private repo (e.g. ZapTen).
  2. Put this zip in the repo root (the workflow unzips it), OR commit the extracted tree.
     The workflow .github/workflows/build.yml is already inside this zip.
  3. Actions builds it → download the artifact "ZapTen-debug-apk" (ZapTen-v1.apk) → sideload.
The toolchain is the same proven set as StreamLine: Gradle 8.11.1, AGP 8.9.2, Kotlin 2.1.20,
JDK 17, compileSdk 36, arm64 only. The SAME debug keystore and alias are reused, so signing is
identical.

FIRST RUN
  1. Open ZapTen. The setup screen shows this box's MAC.
  2. Type your portal address (e.g. your-portal.com or your-portal.com/stalker_portal).
     Portal 2 is optional — it has its own MAC.
  3. Give the shown MAC to your provider to add, like a MAG box.
  4. Choose "Open portal". ZapTen opens the portal page and signs in.
  Next launches open straight into the portal.
  BACK once = the portal's Back; BACK twice quickly = the ZapTen setup screen.

NOT TESTED
  The login maths were checked against a strict fake Ministra portal that recomputes every value
  (handshake + two-step get_profile returned status 0; device_id2 == device_id; signature verified).
  NOT yet built by CI, NOT yet on a real box or a real portal, and there is NO video yet (build 2).
