package com.zapten.app

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * The set-top-box API, exposed to the portal's own c/ interface running in the WebView.
 *
 * A MAG box provides a native `gSTB` object; the portal's JavaScript calls it for the device
 * identity, the login crypto, device info and (later) the player. ZapTen provides the same object:
 * this class is injected as `ZTBridge`, and a small JS shim (injectionJs) builds `window.gSTB` and
 * the other box globals on top of it BEFORE the portal's scripts run. The portal then does the
 * handshake, get_profile and everything else itself, exactly as on a box.
 *
 * Identity + login + device info + the saved box environment (builds 1-5), and from build 6 the box
 * PLAYER API (Play/Stop/Pause/Continue/SetPosTime/GetPosTime/GetMediaLen/SetVolume/SetViewport/
 * SetPIG) handed to BoxPlayerHost — StreamLine's three engines behind the portal page.
 *
 * Methods run on the WebView's JavaScript-bridge thread, not the UI thread.
 */
class StbBridge(private val appCtx: Context, private val portal: Int,
                private val onReboot: () -> Unit = {},
                private val player: BoxPlayerHost? = null,
                private val onOpenWindow: (String) -> Unit = {},
                private val onCloseWindow: () -> Unit = {},
                private val onLoadUrl: (String) -> Unit = {},
                private val onProgress: (Int) -> Unit = {},
                private val onReady: () -> Unit = {},
                private val onTapNothing: () -> Unit = {}) {

    private val mac = BoxPrefs.mac(appCtx, portal)
    private val serial = BoxPrefs.serial(appCtx, portal)
    private val devId = BoxPrefs.deviceId(appCtx, portal).ifBlank { BoxCrypto.macDeviceId(mac) }
    private val devId2 = BoxPrefs.deviceId2(appCtx, portal)

    // ---- identity + login crypto (the portal's gSTB.GetUID / gSTB.GetHashVersion1 delegate here) ----

    /** GetUID() — the primary device id. */
    @JavascriptInterface fun deviceId(): String { DebugLog.add("gSTB.GetUID() -> device_id"); return devId }

    /** GetUID('device_id', token) — the second device id. Build 4: a DIFFERENT value from device_id
     *  (the portal rejected equal ids with "Invalid device (duplicate IDs)"). */
    @JavascriptInterface fun deviceId2(): String { DebugLog.add("gSTB.GetUID(device_id, token) -> device_id2"); return devId2 }

    /** GetUID(random) — the signature = Base64(HMAC-SHA256(key=random, data=device_id)) + "\n". */
    @JavascriptInterface fun sign(random: String): String { DebugLog.add("gSTB.GetUID(random) -> signature (random=" + random.take(8) + "…)"); return BoxCrypto.hmacB64(devId, random) }

    /** GetHashVersion1(a, b) — used for hw_version_2 (metrics, random) and prehash (model, ver56). */
    @JavascriptInterface fun hv1(a: String, b: String): String { DebugLog.add("gSTB.GetHashVersion1(" + (if (a.startsWith("{")) "metrics" else a.take(12)) + ", " + b.take(12) + "…)"); return BoxCrypto.getHashVersion1(a, b) }

    // ---- device info ----
    @JavascriptInterface fun mac(): String = mac
    @JavascriptInterface fun serial(): String = serial
    @JavascriptInterface fun model(): String = BoxCrypto.MODEL
    @JavascriptInterface fun hwVersion(): String = BoxCrypto.HW_VERSION
    @JavascriptInterface fun version(): String = "JS API version: 343; STB API version: 146; Player Engine version: 0x58c"

    /** RDir — the box's environment reader. The interface calls getenv/direct keys at start-up. */
    @JavascriptInterface
    fun rdir(arg: String): String {
        val a = arg.trim()
        DebugLog.add("gSTB.RDir(" + a + ")")
        if (a.startsWith("setenv ")) {
            // "setenv KEY VALUE" — a box writes this to flash. Keep it, so the next start reads it back.
            // (Build 5: the portal sets ntpurl then reboots; before, the value was dropped and the
            // interface stopped at the "reboot" — the black screen after a successful login.)
            val rest = a.substring(7).trim()
            val key = rest.substringBefore(' ').trim()
            val value = rest.substringAfter(' ', "").trim().trim('"')
            if (key.isNotEmpty()) { BoxPrefs.saveEnv(appCtx, portal, key, value); DebugLog.add("  env " + key + " = \"" + value + "\" saved") }
            return ""
        }
        val key = if (a.startsWith("getenv ")) a.substring(7).trim() else a
        BoxPrefs.env(appCtx, portal, key)?.let { return it }   // a value the portal set earlier wins (ntpurl, gmode…)
        return when (key) {
            "language" -> "en"
            "timezone_conf" -> "Europe/London"
            "ntpurl" -> "pool.ntp.org"
            "mtdparts" ->
                // two banks (contains "RootFs2") → num_banks = 2, matching the proven config
                "nand:0x00000000@0x00000000(\"RootFs\"),0x00000000@0x00000000(\"RootFs2\")"
            "update_url" -> ""
            "vmode" -> ""
            "gmode" -> "720"
            "IPAddress" -> ""
            "MACAddress" -> mac
            "SerialNumber" -> serial
            "Model" -> BoxCrypto.MODEL
            "HardwareVersion" -> BoxCrypto.HW_VERSION
            "ImageVersion" -> BoxCrypto.IMAGE_VERSION
            "ImageDescription" -> BoxCrypto.IMAGE_DESCRIPTION
            "ImageDate" -> BoxCrypto.IMAGE_DATE
            "get_storage_info" -> "[]"          // build 8: no USB disks (the portal parses this as JSON)
            else -> ""
        }
    }

    // ---- the box PLAYER API (build 6) — the portal's player.js drives it; BoxPlayerState plays ----
    @JavascriptInterface fun play(uri: String) { player?.play(uri) }
    @JavascriptInterface fun stopPlay() { player?.stop() }
    @JavascriptInterface fun pausePlay() { DebugLog.add("gSTB.Pause()"); player?.pause() }
    @JavascriptInterface fun continuePlay() { DebugLog.add("gSTB.Continue()"); player?.resume() }
    @JavascriptInterface fun setPosTime(sec: Double) { DebugLog.add("gSTB.SetPosTime(" + sec.toLong() + ")"); player?.seekSec(sec.toLong()) }
    @JavascriptInterface fun getPosTime(): Long = player?.posSec() ?: 0
    @JavascriptInterface fun getMediaLen(): Long = player?.lenSec() ?: 0
    @JavascriptInterface fun isPlaying(): Boolean = player?.isPlaying() ?: false
    @JavascriptInterface fun setVolume(v: Double) { player?.setVolume(v.toInt()) }
    /** SetPIG(state, scale, x, y): scale < 0 → full screen; else a window scale×(1280×720) at x,y. */
    @JavascriptInterface fun setPig(state: Double, scale: Double, x: Double, y: Double) {
        DebugLog.add("gSTB.SetPIG(" + state.toInt() + ", " + scale + ", " + x.toInt() + ", " + y.toInt() + ")")
        if (scale <= 0) player?.setViewport(0, 0, 0, 0)
        else player?.setViewport(x.toInt(), y.toInt(), (1280 * scale).toInt(), (720 * scale).toInt())
    }
    /** SetViewport(w, h, x, y) in page pixels (1280×720 space). */
    @JavascriptInterface fun setViewport(w: Double, h: Double, x: Double, y: Double) {
        DebugLog.add("gSTB.SetViewport(" + w.toInt() + "x" + h.toInt() + " @" + x.toInt() + "," + y.toInt() + ")")
        player?.setViewport(x.toInt(), y.toInt(), w.toInt(), h.toInt())
    }

    /** ExecAction — the box's command runner. "reboot" restarts the portal page (a box restarts itself);
     *  "graphicres N" is remembered; everything else is logged and ignored. */
    @JavascriptInterface
    fun execAction(cmd: String) {
        val c = cmd.trim()
        DebugLog.add("gSTB.ExecAction(" + c + ")")
        when {
            c == "reboot" -> { DebugLog.add("  -> reboot: reloading the portal page"); onReboot() }
            c.startsWith("graphicres ") -> BoxPrefs.saveEnv(appCtx, portal, "gmode", c.substringAfter(' ').trim())
        }
    }

    /** SaveUserData(file, data) / LoadUserData(file) — the box's small key/value store (access token). */
    @JavascriptInterface fun saveUserData(file: String, data: String) { DebugLog.add("gSTB.SaveUserData(" + file + ")"); BoxPrefs.saveUserData(appCtx, file, data) }
    @JavascriptInterface fun loadUserData(file: String): String { DebugLog.add("gSTB.LoadUserData(" + file + ")"); return BoxPrefs.userData(appCtx, file) }

    // ---- build 8: the box's second browser window, the portal reload, loading state, touch ----
    /** stbWindowMgr.openWebFavorites / openWebWindow / LoadUrl — the portal's Settings page opens here. */
    @JavascriptInterface fun openWindow(url: String) { DebugLog.add("open window: " + url.take(160)); onOpenWindow(url) }
    /** stbWebWindow.close() — the page in the second window closes itself. */
    @JavascriptInterface fun closeWindow() { DebugLog.add("close window"); onCloseWindow() }
    /** gSTB.LoadURL(url) — a box loads that page in its browser (file:///home/web/… = the portal again). */
    @JavascriptInterface fun loadUrl(url: String) { DebugLog.add("gSTB.LoadURL(" + url.take(160) + ")"); onLoadUrl(url) }
    /** The portal's own loading bar position, 0-100. */
    @JavascriptInterface fun progress(pct: Double) { onProgress(pct.toInt().coerceIn(0, 100)) }
    /** The portal finished loading (its menu or start screen is up). */
    @JavascriptInterface fun ready() { DebugLog.add("portal ready"); onReady() }
    /** A tap on the page that hit no item (e.g. on the full-screen picture). */
    @JavascriptInterface fun tapNothing() { onTapNothing() }

    /** The injected JS reports here (gSTB installed, the login request/response, JS errors) so the
     *  on-screen log shows what happened even when the portal page stays black. */
    @JavascriptInterface fun log(line: String) = DebugLog.add("JS  $line")

    companion object {
        /** The User-Agent the WebView must send so the portal's load.php sees a MAG254. */
        fun userAgent(): String = BoxCrypto.USER_AGENT

        /**
         * The JS injected at document start, before the portal's own scripts. It builds window.gSTB
         * (delegating identity/crypto/info to ZTBridge) plus empty box globals, so the MAG interface
         * finds the box API it expects. gSTB is wrapped in a Proxy so any box method we have not wired
         * yet (the player etc.) is a harmless no-op instead of a crash — until build 2 fills them in.
         */
        fun injectionJs(): String = """
(function(){
  if (window.__ztGstb) { return; }
  window.__ztGstb = true;
  var B = window.ZTBridge;
  if (!B) { return; }
  B.log('shim installed at ' + location.href);
  // Full screen (build 6): the MAG interface lays itself out for the box's video mode, read from
  // screen.height (720 → the 1280×720 layout). Report a 1280×720 screen; the WebView is scaled to
  // fit the real display by ZapTen (setInitialScale), so the page fills the width of the screen.
  try {
    var ztScreen = { width: 1280, height: 720, availWidth: 1280, availHeight: 720 };
    for (var zk in ztScreen) { (function(kk, vv){ Object.defineProperty(window.screen, kk, { get: function(){ return vv; }, configurable: true }); })(zk, ztScreen[zk]); }
  } catch (e) { B.log('screen override failed: ' + e); }
  // The video plays BEHIND the page (like a MAG's video plane): the page background must be see-through.
  function ztCss(){
    if (document.getElementById('zt_css')) { return; }
    var st = document.createElement('style'); st.id = 'zt_css';
    st.textContent = 'html, body { background: transparent !important; }';
    (document.head || document.documentElement).appendChild(st);
    // fixed 1280-wide layout (the box's 720p mode); ZapTen scales it to the real screen width
    var mv = document.createElement('meta'); mv.name = 'viewport'; mv.content = 'width=1280';
    (document.head || document.documentElement).appendChild(mv);
  }
  if (document.documentElement) { ztCss(); }
  document.addEventListener('DOMContentLoaded', ztCss, false);
  window.addEventListener('error', function(e){ try { B.log('JS error: ' + e.message + ' @ ' + (e.filename||'') + ':' + e.lineno); } catch(x){} });
  // log every portal request the page makes (load.php type/action) and its answer size
  (function(){
    var open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(m, u){ this.__zt = String(u); return open.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function(){
      var x = this, u = x.__zt || '';
      var q = /[?&]type=([^&]*)&action=([^&]*)/.exec(u);
      var tag = q ? (q[1] + '/' + q[2]) : u.slice(0, 80);
      x.addEventListener('loadend', function(){
        var body = '';
        try { body = String(x.responseText || '').slice(0, 160).replace(/\s+/g, ' '); } catch(e){}
        try { B.log('xhr ' + tag + ' -> ' + x.status + ' ' + body); } catch(e){}
      });
      return send.apply(this, arguments);
    };
  })();

  // The real box methods ZapTen implements for build 1 (identity, login crypto, device info, store).
  var real = {
    // GetUID(): device_id ; GetUID(random): signature ; GetUID(x, y[, z]): device_id2 (a different id)
    GetUID: function(){
      if (arguments.length === 0) { return B.deviceId(); }
      if (arguments.length === 1) { return B.sign(String(arguments[0])); }
      return B.deviceId2();
    },
    GetHashVersion1: function(a, b){ return B.hv1(String(a == null ? '' : a), String(b == null ? '' : b)); },
    GetDeviceMacAddress: function(){ return B.mac(); },
    GetDeviceSerialNumber: function(){ return B.serial(); },
    GetDeviceModelExt: function(){ return B.model(); },
    GetDeviceVersionHardware: function(){ return B.hwVersion(); },
    GetHDMIConnectionState: function(){ return 1; },
    // build 8: a real MAG254 is not an emulator. As a function this was "true", which made the portal
    // swap its keys (Back acted as Exit) and hide most of the Settings page.
    IsEmulator: false,
    Version: function(){ return B.version(); },
    RDir: function(a){ return B.rdir(String(a == null ? '' : a)); },
    SaveUserData: function(file, data){ B.saveUserData(String(file), String(data == null ? '' : data)); return true; },
    LoadUserData: function(file){ return B.loadUserData(String(file)); },
    // the box PLAYER (build 6) → ZapTen's BoxPlayerState → StreamLine's engines
    Play: function(uri){ B.play(String(uri == null ? '' : uri)); },
    Stop: function(){ B.stopPlay(); },
    Pause: function(){ B.pausePlay(); },
    Continue: function(){ B.continuePlay(); },
    SetPosTime: function(s){ B.setPosTime(Number(s) || 0); },
    GetPosTime: function(){ return B.getPosTime(); },
    GetMediaLen: function(){ return B.getMediaLen(); },
    IsPlaying: function(){ return B.isPlaying(); },
    SetVolume: function(v){ B.setVolume(Number(v) || 0); },
    SetPIG: function(st, sc, x, y){ B.setPig(Number(st) || 0, Number(sc), Number(x) || 0, Number(y) || 0); },
    SetViewport: function(w, h, x, y){ B.setViewport(Number(w) || 0, Number(h) || 0, Number(x) || 0, Number(y) || 0); },
    SetTopWin: function(){}, SetAspect: function(){}, SetLoop: function(){}, SetSpeed: function(){},
    GetVolume: function(){ return 100; }, SetMute: function(){}, GetMute: function(){ return 0; },
    InitPlayer: function(){}, DeinitPlayer: function(){}, SetPlayerOption: function(){}, SetBufferSize: function(){},
    GetBufferLoad: function(){ return 100; }, SetSubtitles: function(){}, SetSubtitlesEncoding: function(){},
    SetSubtitlesSize: function(){}, SetSubtitlesFont: function(){}, SetSubtitlesColor: function(){},
    SetAudioLangs: function(){}, SetSubtitleLangs: function(){}, LoadExternalSubtitles: function(){},
    GetAudioPIDs: function(){ return '[]'; }, GetAudioPIDsEx: function(){ return '[]'; }, GetAudioPID: function(){ return 0; },
    SetAudioPID: function(){}, GetSubtitlePIDs: function(){ return '[]'; }, GetSubtitlePID: function(){ return 0; }, SetSubtitlePID: function(){},
    GetVideoInfo: function(){ return '{}'; }, GetMetadataInfo: function(){ return '{}'; },
    // start-up no-ops (present so calls do not throw; harmless on a WebView)
    Debug: function(){}, ExecAction: function(a){ B.execAction(String(a == null ? '' : a)); }, StandBy: function(){}, StandByMode: function(){ return 0; },
    SetObjectCacheCapacities: function(){}, SetLedIndicatorMode: function(){}, SetLedIndicatorLevels: function(){},
    SetScreenSaverTime: function(){}, SetScreenSaverImplUrl: function(){}, SetScreenSaverInitAttr: function(){},
    SetSettingsInitAttr: function(){}, SetNetRcStatus: function(){}, ConfigNetRc: function(){},
    GetSystemPaths: function(){ return '{}'; },
    // build 8: answers the portal parses as JSON (an empty answer stopped the module loading)
    GetSmbGroups: function(){ return '{"result":[],"errMsg":""}'; },
    GetSmbServers: function(){ return '{"result":[],"errMsg":""}'; },
    GetSmbShares: function(){ return '{"result":[],"errMsg":""}'; },
    // build 8: "go to the portal again" from the settings page (file:///home/web/…) → reload
    LoadURL: function(u){ B.loadUrl(String(u == null ? '' : u)); }
  };

  // Wrap so any box method not listed above is a no-op (returns ''), and force the resize path to
  // use screen.height by making .prototype non-function.
  window.gSTB = new Proxy(real, {
    get: function(t, p){
      if (p === 'prototype') { return undefined; }
      if (p in t) { return t[p]; }
      if (typeof p === 'symbol') { return t[p]; }
      return function(){ return ''; };
    }
  });

  // Other box globals the interface checks for / links to. Empty no-op objects for build 1;
  // build 8: a few methods answer what a MAG254 answers (see the objects passed in).
  function noop(defs){ return new Proxy(defs || {}, { get: function(t, p){
    if (p in t) { return t[p]; }
    if (typeof p === 'symbol') { return t[p]; }
    return function(){ return ''; };
  }}); }
  function ztEmpty(){ return '[]'; }
  function ztOpen(u){ B.openWindow(String(u == null ? '' : u)); }
  // build 8: the box's second browser window (the portal opens its Settings page in it) → ZapTen
  // opens that page full screen over the portal; the page's stbWebWindow.close() closes it again.
  window.stbWebWindow       = noop({ close: function(){ B.closeWindow(); } });
  window.stbWindowMgr       = noop({
    openWebFavorites: ztOpen, openWebWindow: ztOpen, LoadUrl: ztOpen,
    openWebFace: function(p){ var m = /[?&]url=([^&]*)/.exec(String(p)); if (m) { ztOpen(decodeURIComponent(m[1])); } else { B.log('openWebFace ' + p); } },
    InitWebWindow: function(){}, raiseWebWindow: function(){}
  });
  window.stbStorage         = noop();
  window.stbUpdate          = noop();
  window.stbDownloadManager = noop({ GetQueueInfo: ztEmpty });
  window.stbUPnP            = noop();
  // build 8: "no tuner" like a MAG254 — an empty answer here crashed the DVB/Settings modules and
  // stopped the portal loading every module after them (the missing Settings / Account info tiles)
  window.dvbManager         = noop({ GetSupportedScanTypes: ztEmpty, GetCurrentScanTypes: ztEmpty, GetChannelList: ztEmpty, GetEPGSchedule: ztEmpty });
  window.pvrManager         = noop({ GetAllTasks: ztEmpty });
  window.timeShift          = noop();
  window.stbEvent           = {};   // the interface ASSIGNS handlers onto this (onPortalEvent = …)
  window.stbPlayerManager   = noop();

  // ---- logging, so the on-screen panel shows what the portal actually did ----
  // Any script error on the portal page.
  window.addEventListener('error', function(e){
    try { B.log('PAGE ERROR ' + (e.message || '') + ' @' + (e.filename || '') + ':' + (e.lineno || '')); } catch(x){}
  });
  // The login traffic: log each server request's URL and the start of its response (this is where
  // "Authorization failed", a block message, or the token/profile shows up).
  try {
    var O = XMLHttpRequest.prototype.open, S = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(m, u){ this.__ztU = u; this.__ztM = m; return O.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function(){
      var x = this, u = String(x.__ztU || '');
      if (u.indexOf('load.php') >= 0 || u.indexOf('/server/') >= 0 || u.indexOf('portal.php') >= 0) {
        B.log('REQ ' + (x.__ztM || 'GET') + ' ' + u.slice(0, 160));
        x.addEventListener('load', function(){
          try { B.log('RESP ' + x.status + ' ' + String(x.responseText).slice(0, 220)); } catch(e){}
        });
        x.addEventListener('error', function(){ try { B.log('RESP ERROR (network) ' + u.slice(0, 120)); } catch(e){} });
      }
      return S.apply(this, arguments);
    };
  } catch(e){ B.log('xhr hook failed: ' + e); }

  // ---- build 8: loading progress + "the portal is up" (ZapTen shows its own loading screen until then) ----
  if (window.top === window) {
    var ztUp = false, ztPct = -1, ztPolls = 0;
    var ztPoll = setInterval(function(){
      ztPolls++;
      try {
        if (window.stb && stb.loader && typeof stb.loader.cur_pos === 'number') {
          var pct = Math.max(0, Math.min(100, Math.round(stb.loader.cur_pos)));
          if (pct !== ztPct) { ztPct = pct; B.progress(pct); }
        }
        var up = (window.main_menu && window.main_menu.on === true) ||
                 (window.stb && stb.loader && stb.loader.on === false && ztPct > 0);
        if (up && !ztUp) { ztUp = true; B.ready(); }
      } catch (e) {}
      if (ztUp || ztPolls > 400) { clearInterval(ztPoll); }
    }, 300);
  }

  // ---- build 8: touch like StreamLine. The MAG interface only listens to remote keys, so a tap
  // becomes the arrow presses that move the portal's own highlight onto what was tapped, then OK;
  // a swipe becomes arrow presses (finger up = Down). Works in every frame, so the Settings window's
  // pages (they also only follow keys) get it too; text boxes, buttons and links get the tap as it is.
  if (true) {
    var ZT_HL = /(^|[\s_-])(act|active)($|[\s_-])|_ring($|[\s_-])|(^|\s)sl_focus($|\s)/;
    var ztIds = 0, ztT = null, ZT_STEP = 64;
    var ztTouchCss = function(){
      if (document.getElementById('zt_touch_css')) { return; }
      var st = document.createElement('style'); st.id = 'zt_touch_css';
      st.textContent = 'html, body { -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; -webkit-tap-highlight-color: rgba(0,0,0,0); touch-action: none; }';
      (document.head || document.documentElement).appendChild(st);
    };
    if (document.documentElement) { ztTouchCss(); }
    document.addEventListener('DOMContentLoaded', ztTouchCss, false);
    var ztKey = function(code){
      var e = new KeyboardEvent('keydown', { bubbles: true, cancelable: true });
      Object.defineProperty(e, 'keyCode', { get: function(){ return code; } });
      Object.defineProperty(e, 'which', { get: function(){ return code; } });
      // on the body, so both kinds of page see it: the portal listens on the document (it bubbles
      // up there), the Settings pages use <body onkeydown>
      (document.body || document).dispatchEvent(e);
    };
    var ztIsInput = function(el){
      for (var n = el, i = 0; n && n.nodeType === 1 && i < 4; n = n.parentElement, i++) {
        if (n.tagName === 'INPUT' || n.tagName === 'TEXTAREA' || n.tagName === 'SELECT' || n.tagName === 'BUTTON' || n.tagName === 'A' || n.isContentEditable) { return true; }
      }
      return false;
    };
    var ztNothing = function(){ if (window.top === window) { B.tapNothing(); } };
    var ztVisible = function(el){
      var r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) { return null; }
      if (r.right < 0 || r.bottom < 0 || r.left > innerWidth || r.top > innerHeight) { return null; }
      var cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') { return null; }
      if (el.offsetParent === null && cs.position !== 'fixed') { return null; }
      return r;
    };
    var ztCommon = function(a, b){
      var anc = [];
      for (var n = a; n; n = n.parentNode) { anc.push(n); }
      for (var m = b; m; m = m.parentNode) { var i = anc.indexOf(m); if (i >= 0) { return anc.length - i; } }
      return 0;
    };
    // The portal's highlighted item nearest (in the page structure, then on screen) to the tapped one.
    var ztHighlight = function(el, x, y){
      var all = document.querySelectorAll('[class]'), best = null, bestD = -1, bestDist = 0;
      var big = innerWidth * innerHeight * 0.4;
      for (var i = 0; i < all.length; i++) {
        var c = all[i];
        if (c === document.body || c === document.documentElement) { continue; }
        var cn = typeof c.className === 'string' ? c.className : (c.getAttribute('class') || '');
        if (!ZT_HL.test(cn)) { continue; }
        var r = ztVisible(c);
        if (!r || r.width * r.height > big) { continue; }
        var d = ztCommon(el, c);
        var dist = Math.abs(r.left + r.width / 2 - x) + Math.abs(r.top + r.height / 2 - y);
        if (d > bestD || (d === bestD && dist < bestDist)) { best = c; bestD = d; bestDist = dist; }
      }
      return best;
    };
    var ztSig = function(h, el){
      if (!h.__ztId) { h.__ztId = ++ztIds; }
      var r = h.getBoundingClientRect(), t = el.getBoundingClientRect();
      return h.__ztId + ':' + Math.round(r.left) + ',' + Math.round(r.top) + ':' + Math.round(t.left) + ',' + Math.round(t.top);
    };
    var ztTap = function(x, y){
      var el = document.elementFromPoint(x, y);
      if (!el || el === document.documentElement || el === document.body) { ztNothing(); return; }
      // the side tabs (left = Back / previous, right = next) and the colour-button bar
      for (var a = el, i = 0; a && a.nodeType === 1 && i < 10; a = a.parentElement, i++) {
        var c = typeof a.className === 'string' ? a.className : '';
        if (/(^|\s)ears_left/.test(c)) { ztKey(37); return; }
        if (/(^|\s)ears_right/.test(c)) { ztKey(39); return; }
        if (a.tagName === 'TD' && a.closest && a.closest('.color_button_bar')) { ztKey(112 + Math.max(0, Math.min(3, a.cellIndex))); return; }
      }
      var h = ztHighlight(el, x, y);
      if (!h) { ztNothing(); return; }
      var hr = h.getBoundingClientRect(), t0 = el.getBoundingClientRect();
      if (!h.contains(el) && !el.contains(h) && t0.width * t0.height > 8 * hr.width * hr.height) { ztNothing(); return; }
      var ox = x - t0.left, oy = y - t0.top;
      for (var step = 0; step < 40; step++) {
        hr = h.getBoundingClientRect();
        var p = { x: x, y: y };
        if (document.documentElement.contains(el)) { var tr = el.getBoundingClientRect(); p = { x: tr.left + ox, y: tr.top + oy }; }
        if (h === el || h.contains(el) || (p.x >= hr.left && p.x <= hr.right && p.y >= hr.top && p.y <= hr.bottom)) { ztKey(13); return; }
        var dir = p.y > hr.bottom ? 40 : (p.y < hr.top ? 38 : (p.x > hr.right ? 39 : 37));
        var before = ztSig(h, el);
        ztKey(dir);
        var h2 = ztHighlight(el, p.x, p.y);
        if (!h2) { return; }
        if (ztSig(h2, el) === before) {
          var other = (dir === 38 || dir === 40) ? (p.x > hr.right ? 39 : (p.x < hr.left ? 37 : 0))
                                                 : (p.y > hr.bottom ? 40 : (p.y < hr.top ? 38 : 0));
          if (!other) { return; }
          ztKey(other);
          h2 = ztHighlight(el, p.x, p.y);
          if (!h2 || ztSig(h2, el) === before) { return; }
        }
        h = h2;
      }
    };
    document.addEventListener('touchstart', function(e){
      if (e.touches.length !== 1) { ztT = null; return; }
      var t = e.touches[0];
      ztT = { x: t.clientX, y: t.clientY, lx: t.clientX, ly: t.clientY, at: Date.now(), moved: false, axis: '',
              own: !ztIsInput(e.target) };
    }, { capture: true, passive: true });
    document.addEventListener('touchmove', function(e){
      var s = ztT;
      if (!s || !s.own || e.touches.length !== 1) { return; }
      var t = e.touches[0];
      if (!s.moved && Math.abs(t.clientX - s.x) < 12 && Math.abs(t.clientY - s.y) < 12) { return; }
      s.moved = true;
      if (!s.axis) { s.axis = Math.abs(t.clientY - s.y) >= Math.abs(t.clientX - s.x) ? 'y' : 'x'; }
      if (s.axis === 'y') {
        while (t.clientY - s.ly <= -ZT_STEP) { ztKey(40); s.ly -= ZT_STEP; }
        while (t.clientY - s.ly >= ZT_STEP) { ztKey(38); s.ly += ZT_STEP; }
      } else {
        while (t.clientX - s.lx <= -ZT_STEP) { ztKey(39); s.lx -= ZT_STEP; }
        while (t.clientX - s.lx >= ZT_STEP) { ztKey(37); s.lx += ZT_STEP; }
      }
      if (e.cancelable) { e.preventDefault(); }
    }, { capture: true, passive: false });
    document.addEventListener('touchend', function(e){
      var s = ztT; ztT = null;
      if (!s || !s.own) { return; }
      if (e.cancelable) { e.preventDefault(); }
      if (s.moved || Date.now() - s.at > 800) { return; }
      try { ztTap(s.x, s.y); } catch (x) { B.log('tap failed: ' + x); }
    }, { capture: true, passive: false });
  }

  B.log('gSTB installed (model MAG254)');
})();
""".trimIndent()
    }
}
