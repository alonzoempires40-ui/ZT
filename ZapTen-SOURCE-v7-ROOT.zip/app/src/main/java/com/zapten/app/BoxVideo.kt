package com.zapten.app

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import dev.jdtech.mpv.MPVLib
import kotlinx.coroutines.delay

/**
 * ZapTen portal mode — the BOX PLAYER. The portal's own interface (c/) calls the set-top-box player
 * API (gSTB.Play / Stop / Pause / Continue / SetPosTime / GetPosTime / GetMediaLen / SetViewport …)
 * through StbBridge; this is what sits underneath and actually plays, using StreamLine's three
 * engines UNCHANGED: ExoPlayer for HLS, mpv for transport streams (hardware decode + embedded
 * subtitles), libVLC as the fallback (FFmpeg decoders, legacy Greek subtitles). The routing and the
 * error fallback (Exo → VLC → mpv) are StreamLine's (Player.kt pickEngine), minus the title check —
 * the portal only hands us a URL.
 *
 * The video is drawn BEHIND the (transparent) portal page, exactly like a MAG's video plane: full
 * screen normally, or in the small preview window the interface asks for with SetViewport/SetPIG.
 *
 * Box events the interface waits for (player.js event_callback): 4 = playback started,
 * 1 = end of stream, 5 = not found / cannot play. Sent with stbEvent.onEvent(code).
 */

/** What the bridge needs from the player. Calls may come from the WebView's JS thread. */
interface BoxPlayerHost {
    fun play(url: String)
    fun stop()
    fun pause()
    fun resume()
    fun seekSec(sec: Long)
    fun setVolume(pct: Int)
    /** Page coordinates (1280×720 space). w <= 0 → full screen. */
    fun setViewport(x: Int, y: Int, w: Int, h: Int)
    fun posSec(): Long
    fun lenSec(): Long
    fun isPlaying(): Boolean
}

/** Playback state shared between the bridge (JS thread), the video layer (compose) and the page. */
class BoxPlayerState : BoxPlayerHost {
    private val main = Handler(Looper.getMainLooper())

    // compose-observed
    var url by mutableStateOf<String?>(null)
    var engine by mutableStateOf("exo")
    var gen by mutableStateOf(0)                       // bumps to force a fresh player
    var rect by mutableStateOf<IntArray?>(null)        // page px [x,y,w,h]; null = full screen
    var volumePct by mutableStateOf(100)

    // live controller + snapshot for the bridge thread
    @Volatile var controller: PlaybackController? = null
    @Volatile private var snapPos = 0L
    @Volatile private var snapLen = 0L
    @Volatile private var snapPlaying = false
    @Volatile var started = false
    private var triedVlc = false
    private var triedMpv = false

    /** Set by the portal screen: sends stbEvent.onEvent(code) into the page. */
    var sendEvent: (Int) -> Unit = {}

    // ---- StreamLine's engine choice, by URL (Player.kt pickEngine without the title rule) ----
    private fun pickEngine(u: String): String {
        val low = u.lowercase()
        val looksHls = low.contains(".m3u8")
        val looksTs = low.contains("mpegts") || low.contains(".ts") || low.contains("/ts") ||
            low.startsWith("rtp") || low.startsWith("udp") || low.startsWith("rtsp")
        return when {
            looksTs -> "mpv"
            looksHls -> "exo"
            else -> "exo"
        }
    }

    /** "ffmpeg http://…", "auto http://…", "ffrt …" → the URL itself (the box solution word is dropped). */
    private fun stripSolution(uri: String): String {
        val s = uri.trim()
        val sp = s.indexOf(' ')
        return if (sp > 0 && !s.substring(0, sp).contains("://")) s.substring(sp + 1).trim() else s
    }

    override fun play(url: String) = main.post {
        val u = stripSolution(url)
        DebugLog.add("player: Play " + u.take(120))
        started = false; triedVlc = false; triedMpv = false
        snapPos = 0; snapLen = 0; snapPlaying = false
        engine = pickEngine(u)
        this.url = u
        gen++
        DebugLog.add("player: engine " + engine)
    }.let { }

    override fun stop() = main.post {
        if (url != null) DebugLog.add("player: Stop")
        url = null; controller = null; started = false
        snapPos = 0; snapLen = 0; snapPlaying = false
    }.let { }

    override fun pause() = main.post { controller?.let { if (it.isPlaying()) it.playPause() } }.let { }
    override fun resume() = main.post { controller?.let { if (!it.isPlaying()) it.playPause() } }.let { }
    override fun seekSec(sec: Long) = main.post { controller?.seekTo(sec * 1000) }.let { }
    override fun setVolume(pct: Int) = main.post { volumePct = pct.coerceIn(0, 100); applyVolume() }.let { }
    override fun setViewport(x: Int, y: Int, w: Int, h: Int) = main.post {
        rect = if (w <= 0 || h <= 0) null else intArrayOf(x, y, w, h)
        DebugLog.add("player: viewport " + (rect?.joinToString(",") ?: "full screen"))
    }.let { }

    override fun posSec(): Long = snapPos / 1000
    override fun lenSec(): Long = snapLen / 1000
    override fun isPlaying(): Boolean = snapPlaying

    /** Called by the engine composables (main thread). */
    fun attach(c: PlaybackController) { controller = c; applyVolume() }

    fun applyVolume() {
        val v = volumePct
        when (val c = controller) {
            is ExoController -> c.exo?.volume = v / 100f
            is VlcController -> runCatching { c.player?.volume = v }
            is MpvController -> if (c.ready) runCatching { MPVLib.setPropertyString("volume", v.toString()) }
            else -> {}
        }
    }

    /** Polled from the video layer (main thread): updates the snapshot, raises started / ended. */
    fun poll() {
        val c = controller ?: return
        val playing = c.isPlaying(); val pos = c.positionMs(); val len = c.durationMs()
        snapPlaying = playing; snapPos = pos; snapLen = len
        if (!started && (playing || pos > 0)) { started = true; DebugLog.add("player: started → event 4"); sendEvent(4) }
        // VOD end for the polled engines (VLC / mpv): past the end and no longer playing
        if (started && len > 0 && !playing && pos >= len - 1500 && engine != "exo") onEnded()
    }

    fun onStarted() { if (!started) { started = true; DebugLog.add("player: started → event 4"); sendEvent(4) } }
    fun onEnded() {
        if (url == null) return
        DebugLog.add("player: end of stream → event 1")
        url = null; controller = null; started = false; snapPlaying = false
        sendEvent(1)
    }

    /** StreamLine's fallback chain: Exo → VLC → mpv → give up (box event 5). */
    fun onError(which: String, why: String) {
        DebugLog.add("player: " + which + " error: " + why)
        if (url == null) return
        when {
            which == "exo" && !triedVlc -> { triedVlc = true; engine = "vlc"; gen++; DebugLog.add("player: falling back to VLC") }
            which == "vlc" && !triedMpv -> { triedMpv = true; engine = "mpv"; gen++; DebugLog.add("player: falling back to mpv") }
            which == "mpv" && !triedVlc -> { triedVlc = true; engine = "vlc"; gen++; DebugLog.add("player: falling back to VLC") }
            else -> { DebugLog.add("player: cannot play → event 5"); url = null; controller = null; started = false; sendEvent(5) }
        }
    }
}

/** ExoPlayer behind StreamLine's engine-agnostic controller surface (the Exo path of Player.kt). */
class ExoController : PlaybackController {
    var exo: ExoPlayer? = null
    override fun playPause() { exo?.let { if (it.isPlaying) it.pause() else it.play() } }
    override fun isPlaying(): Boolean = exo?.isPlaying ?: false
    override fun positionMs(): Long = exo?.currentPosition ?: 0
    override fun durationMs(): Long = exo?.duration?.takeIf { it > 0 } ?: 0
    override fun seekTo(ms: Long) { exo?.seekTo(ms) }
    override fun seekBy(deltaMs: Long) = seekTo((positionMs() + deltaMs).coerceAtLeast(0))
    override fun setRate(rate: Float) { exo?.setPlaybackSpeed(rate) }
    override fun audioTracks(): List<TrackOption> = emptyList()
    override fun subtitleTracks(): List<TrackOption> = emptyList()
    override fun currentAudio(): Int = -1
    override fun currentSpu(): Int = -1
    override fun selectAudio(id: Int) {}
    override fun selectSpu(id: Int) {}
    override fun enableFirstSubtitle(): Int = -1
}

/** The video layer: full screen or the interface's preview window, one of the three engines. */
@Composable
fun BoxVideo(state: BoxPlayerState, referer: String, viewWidthPx: Int) {
    val url = state.url
    val density = LocalDensity.current.density
    // page (1280-wide) → view pixels
    val k = if (viewWidthPx > 0) viewWidthPx / 1280f else 1f
    val r = state.rect
    val mod = if (r == null) Modifier.fillMaxSize() else
        Modifier.offset { IntOffset((r[0] * k).toInt(), (r[1] * k).toInt()) }
            .size(((r[2] * k) / density).dp, ((r[3] * k) / density).dp)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (url != null) {
            key(state.gen, url, state.engine) {
                when (state.engine) {
                    "vlc" -> {
                        val c = remember { VlcController() }
                        LaunchedEffect(Unit) { state.attach(c) }
                        VlcPlayer(url, c, mod, userAgent = BoxCrypto.USER_AGENT, referer = referer,
                            onError = { state.onError("vlc", "EncounteredError") })
                    }
                    "mpv" -> {
                        val c = remember { MpvController() }
                        LaunchedEffect(Unit) { state.attach(c) }
                        MpvPlayer(url, c, mod, userAgent = BoxCrypto.USER_AGENT, referer = referer,
                            onError = { state.onError("mpv", "init failed") })
                    }
                    else -> ExoBox(url, state, referer, mod)
                }
                // the snapshot the bridge reads, and started/ended for the polled engines
                LaunchedEffect(Unit) { while (true) { state.poll(); delay(400) } }
            }
        }
    }
}

@Composable
private fun ExoBox(url: String, state: BoxPlayerState, referer: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val c = remember { ExoController() }
    val exo = remember(url) {
        // StreamLine's Exo setup: the box User-Agent (+ Referer) the streamers gate on.
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(BoxCrypto.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setKeepPostFor302Redirects(true)
            .setDefaultRequestProperties(mapOf("Referer" to referer))
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory)).build().apply {
            trackSelectionParameters = trackSelectionParameters.buildUpon().setSelectUndeterminedTextLanguage(true).build()
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) state.onStarted()
                    if (playbackState == Player.STATE_ENDED) state.onEnded()
                }
                override fun onPlayerError(error: PlaybackException) { state.onError("exo", error.errorCodeName) }
            })
            setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true
        }
    }
    c.exo = exo
    LaunchedEffect(exo) { state.attach(c) }
    AndroidView(
        factory = { cx -> PlayerView(cx).apply { useController = false; player = exo; setBackgroundColor(android.graphics.Color.BLACK) } },
        update = { it.player = exo },
        modifier = modifier
    )
    DisposableEffect(exo) { onDispose { c.exo = null; runCatching { exo.release() } } }
}
