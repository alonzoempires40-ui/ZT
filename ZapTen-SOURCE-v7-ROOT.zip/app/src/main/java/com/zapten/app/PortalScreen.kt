package com.zapten.app

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.net.http.SslError
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/*
 * ZapTen portal mode (build 6) — the provider's own MAG interface (stalker_portal/c/) in a WebView
 * with the set-top-box API (StbBridge) underneath, StreamLine's three video engines behind it
 * (BoxVideo), an on-screen remote for touch screens, and the log. Added on top of StreamLine 40
 * unchanged; StreamLine's own screens stay reachable from the setup screen.
 */

/** Setup: portal address(es) and this box's MAC to give the provider. */
@Composable
fun ZtSetupScreen(onOpen: () -> Unit, onStreamLine: () -> Unit) {
    val ctx = LocalContext.current
    var active by remember { mutableStateOf(BoxPrefs.activePortal(ctx)) }
    var url1 by remember { mutableStateOf(BoxPrefs.url(ctx, 1)) }
    var url2 by remember { mutableStateOf(BoxPrefs.url(ctx, 2)) }
    val mac = remember(active) { BoxPrefs.mac(ctx, active) }

    Column(Modifier.fillMaxSize().background(Ink).verticalScroll(rememberScrollState()).padding(28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zap", color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Ten", color = Amber, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(4.dp))
        Text("Opens your provider's own portal, like a set-top box.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))

        Text("PORTAL", color = Amber, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ZtChip("Portal 1", active == 1) { active = 1; BoxPrefs.saveActivePortal(ctx, 1) }
            ZtChip("Portal 2", active == 2) { active = 2; BoxPrefs.saveActivePortal(ctx, 2) }
        }
        Spacer(Modifier.height(20.dp))

        ZtField("Portal $active address", if (active == 1) url1 else url2, placeholder = "subdomain.domain.com") { v ->
            if (active == 1) url1 = v else url2 = v
        }
        Spacer(Modifier.height(16.dp))

        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(16.dp)) {
            Text("THIS BOX'S MAC — give it to your provider", color = Amber, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(mac, color = TextCol, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Portal $active uses this MAC. Portal 1 and Portal 2 each have their own.", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                BoxPrefs.saveUrl(ctx, 1, url1); BoxPrefs.saveUrl(ctx, 2, url2); BoxPrefs.saveActivePortal(ctx, active)
                if (BoxPrefs.url(ctx, active).isNotBlank()) { BoxPrefs.markSetupDone(ctx); onOpen() }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304)),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Open portal $active", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onStreamLine,
            colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = TextCol),
            modifier = Modifier.fillMaxWidth().height(44.dp)
        ) { Text("StreamLine screens (the app's own interface)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        Spacer(Modifier.height(8.dp))
        Text("The StreamLine screens use their own MAC (shown on their welcome screen), separate from the one above.",
            color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ZtChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(label, color = if (selected) Color(0xFF1A1304) else TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.background(if (selected) Amber else Panel, RoundedCornerShape(10.dp)).clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 9.dp))
}

@Composable
private fun ZtField(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = true,
            placeholder = { Text(placeholder, color = Muted, fontSize = 13.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Amber, unfocusedBorderColor = Line,
                focusedTextColor = TextCol, unfocusedTextColor = TextCol, cursorColor = Amber),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Only the domain is needed: no scheme → https://, no path → /stalker_portal, then /c/. */
fun ztPortalPageUrl(input: String): String {
    var s = input.trim()
    if (s.isEmpty()) return ""
    if (!s.startsWith("http://") && !s.startsWith("https://")) s = "https://$s"
    s = s.trimEnd('/')
    s = s.removeSuffix("/c").trimEnd('/')
    val path = s.substringAfter("://").substringAfter('/', "")
    if (path.isEmpty()) s = "$s/stalker_portal"
    return "$s/c/"
}

/** The portal page over the box player, plus the controls. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ZtPortalScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val portal = remember { BoxPrefs.activePortal(ctx) }
    val pageUrl = remember { ztPortalPageUrl(BoxPrefs.url(ctx, portal)) }
    val player = remember { BoxPlayerState() }
    var webRef by remember { mutableStateOf<WebView?>(null) }
    var lastBack by remember { mutableStateOf(0L) }
    var showLog by remember { mutableStateOf(false) }
    val hasTouch = remember { ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN) }
    var showRemote by remember { mutableStateOf(hasTouch) }
    val viewWidthPx = remember { ctx.resources.displayMetrics.widthPixels }

    // A remote key for the portal page (its keydown observer): code + Shift/Alt, like a MAG remote.
    fun sendKey(code: Int, shift: Boolean = false, alt: Boolean = false) {
        webRef?.evaluateJavascript(
            "(function(){var e=new KeyboardEvent('keydown',{bubbles:true,shiftKey:" + shift + ",altKey:" + alt + "});" +
                "Object.defineProperty(e,'keyCode',{get:function(){return " + code + "}});" +
                "Object.defineProperty(e,'which',{get:function(){return " + code + "}});" +
                "document.dispatchEvent(e);})();", null)
    }

    BackHandler {
        if (showLog) { showLog = false; return@BackHandler }
        val now = System.currentTimeMillis()
        if (now - lastBack < 1500) onSettings() else { lastBack = now; sendKey(8); sendKey(27) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // 1. the box player, behind everything (full screen or the interface's preview window)
        BoxVideo(player, referer = pageUrl, viewWidthPx = viewWidthPx)

        // 2. the portal page, transparent, scaled so its 1280-wide layout fills the screen width
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                CookieManager.getInstance().setAcceptCookie(true)
                DebugLog.add("open portal " + portal + ": " + pageUrl)
                DebugLog.add("MAC " + BoxPrefs.mac(ctx, portal) + "  serial " + BoxPrefs.serial(ctx, portal))
                WebView(c).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)   // the video shows through
                    isVerticalScrollBarEnabled = false; isHorizontalScrollBarEnabled = false
                    overScrollMode = android.view.View.OVER_SCROLL_NEVER
                    isFocusable = true; isFocusableInTouchMode = true
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    with(settings) {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        userAgentString = StbBridge.userAgent()
                        @Suppress("DEPRECATION")
                        mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        // Full screen: the page lays out 1280 wide (screen.height is reported as 720 by the
                        // shim); the initial scale maps those 1280 CSS px onto the real screen width.
                        useWideViewPort = true
                        loadWithOverviewMode = false
                        setSupportZoom(false); builtInZoomControls = false; displayZoomControls = false
                        setSupportMultipleWindows(false)
                    }
                    val scale = (viewWidthPx / 1280f * 100f).toInt().coerceAtLeast(1)
                    setInitialScale(scale)
                    DebugLog.add("page scale " + scale + "% (screen " + viewWidthPx + " px wide → 1280 px layout)")

                    val web = this
                    player.sendEvent = { code -> web.post { web.evaluateJavascript("try{stbEvent.onEvent(" + code + ")}catch(e){}", null) } }
                    val rebootTimes = java.util.ArrayDeque<Long>()
                    addJavascriptInterface(StbBridge(c.applicationContext, portal, onReboot = {
                        web.post {
                            val now = System.currentTimeMillis()
                            while (rebootTimes.isNotEmpty() && now - rebootTimes.peekFirst()!! > 60_000) rebootTimes.pollFirst()
                            rebootTimes.addLast(now)
                            if (rebootTimes.size > 3) DebugLog.add("--- reboot asked " + rebootTimes.size + "x in a minute: STOPPED (loop) ---")
                            else { DebugLog.add("--- reboot (reload) ---"); player.stop(); web.loadUrl(pageUrl) }
                        }
                    }, player = player), "ZTBridge")
                    val js = StbBridge.injectionJs()
                    val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
                    DebugLog.add("document-start injection supported: " + docStart)
                    if (docStart) WebViewCompat.addDocumentStartJavaScript(this, js, setOf("*"))
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                            DebugLog.add("console[" + m.messageLevel() + "] " + m.message() + "  (" + m.sourceId().substringAfterLast('/') + ":" + m.lineNumber() + ")")
                            return true
                        }
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            DebugLog.add("page started: " + url)
                            if (!docStart) view.evaluateJavascript(js, null)
                        }
                        override fun onPageFinished(view: WebView, url: String?) {
                            super.onPageFinished(view, url)
                            DebugLog.add("page finished: " + url)
                            view.requestFocus()      // a TV remote's keys go to the page
                            view.evaluateJavascript(
                                "(function(){return 'gSTB=' + (typeof gSTB) + ' stb=' + (typeof stb) + ' screen=' + screen.width + 'x' + screen.height + ' inner=' + innerWidth + 'x' + innerHeight + ' bodyLen=' + (document.body ? document.body.innerHTML.length : -1);})()"
                            ) { r -> DebugLog.add("page state: " + r) }
                        }
                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            super.onReceivedError(view, request, error)
                            DebugLog.add((if (request.isForMainFrame) "MAIN " else "") + "load error " + error.errorCode + " " + error.description + " : " + request.url)
                        }
                        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                            super.onReceivedHttpError(view, request, response)
                            DebugLog.add((if (request.isForMainFrame) "MAIN " else "") + "HTTP " + response.statusCode + " " + response.reasonPhrase + " : " + request.url)
                        }
                        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                            DebugLog.add("SSL error " + error.primaryError + " : " + error.url + "  (connection refused — certificate not trusted)")
                            handler.cancel()
                        }
                    }
                    webRef = this
                    if (pageUrl.isNotBlank()) loadUrl(pageUrl) else DebugLog.add("no portal address saved")
                }
            }
        )

        // 3. controls (top-right): Settings · Reload · Log · Remote
        Row(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ZtBtn("Settings") { onSettings() }
            ZtBtn("Reload") { DebugLog.add("--- reload ---"); player.stop(); webRef?.loadUrl(pageUrl) }
            ZtBtn(if (showLog) "Hide log" else "Log") { showLog = !showLog }
            ZtBtn(if (showRemote) "Hide remote" else "Remote") { showRemote = !showRemote }
        }

        // 4. on-screen remote for touch screens: the MAG interface only listens to remote keys
        if (showRemote) ZtRemote(Modifier.align(Alignment.BottomEnd).padding(12.dp)) { code, shift, alt -> sendKey(code, shift, alt) }

        if (showLog) ZtLogPanel(onClear = { DebugLog.clear() }, onCopy = {
            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("ZapTen log", DebugLog.dump()))
        })
    }
}

@Composable
private fun ZtBtn(label: String, onClick: () -> Unit) {
    Text(label, color = TextCol, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.background(Color(0xCC141927), RoundedCornerShape(8.dp)).clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp))
}

/** A MAG remote on screen (keydown.keycodes.js): arrows, OK, Back, Exit, Menu, CH±, Info, ▶❚❚, ■, colours. */
@Composable
private fun ZtRemote(modifier: Modifier, send: (Int, Boolean, Boolean) -> Unit) {
    @Composable
    fun K(label: String, code: Int, shift: Boolean = false, alt: Boolean = false, bg: Color = Color(0xCC1C2336), w: Int = 54) {
        Text(label, color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.width(w.dp).height(40.dp).background(bg, RoundedCornerShape(9.dp))
                .clickable { send(code, shift, alt) }.wrapContentHeight(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
    Column(modifier.background(Color(0x990B0E16), RoundedCornerShape(14.dp)).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("Back", 8); K("▲", 38); K("Menu", 122) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("◀", 37); K("OK", 13, bg = Color(0xCCF5B638)); K("▶", 39) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("Exit", 27); K("▼", 40); K("Info", 89, alt = true) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("CH−", 9, shift = true); K("CH+", 9); K("▶❚❚", 82, alt = true); K("■", 83, alt = true) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            K("", 112, bg = Color(0xCCB03030), w = 40); K("", 113, bg = Color(0xCC2E8B57), w = 40)
            K("", 114, bg = Color(0xCCC9A227), w = 40); K("", 115, bg = Color(0xCC2F5FB0), w = 40)
        }
    }
}

/** The log: newest at the bottom; Copy puts the whole log on the clipboard. */
@Composable
private fun ZtLogPanel(onClear: () -> Unit, onCopy: () -> Unit) {
    val lines = DebugLog.lines
    val scroll = rememberScrollState()
    LaunchedEffect(lines.size) { scroll.scrollTo(scroll.maxValue) }
    Column(Modifier.fillMaxWidth().fillMaxHeight(0.6f).padding(top = 44.dp, start = 10.dp, end = 10.dp)
        .background(Color(0xE60B0E16), RoundedCornerShape(10.dp)).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ZapTen log  ·  " + lines.size + " lines", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            ZtBtn("Copy") { onCopy() }
            Spacer(Modifier.width(6.dp))
            ZtBtn("Clear") { onClear() }
        }
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
            for (l in lines) Text(l, color = TextCol, fontSize = 11.sp, lineHeight = 14.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
