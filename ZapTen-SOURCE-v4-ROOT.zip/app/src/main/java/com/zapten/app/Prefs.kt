package com.zapten.app

import android.content.Context

/**
 * ZapTen's saved settings: two portals, each with its OWN permanent box identity, exactly like a
 * MAG box and like the StreamLine project (same generation mechanism). Generated ONCE, stored
 * sealed via the Vault, never changed for this install. The provider adds each portal's MAC like
 * a set-top box.
 *
 * Identity per portal: only the MAC is stored (Infomir 00:1A:79 range, generated once, or whatever
 * the user typed). The serial and the device id are DERIVED from the MAC, so they need no storage
 * and are reproducible — the same deterministic derivation the proven StreamLine TV login service
 * uses: serial = upper(MD5(MAC))[0..13], device_id = upper(SHA-256(MAC)); device_id2 =
 * upper(SHA-256(serial + MAC)) — DIFFERENT from device_id (build 4: the portal refuses equal ids).
 * The signature is HMAC(device_id, random), computed fresh at each login from the portal's random,
 * which is how a box works.
 */
object Prefs {
    private const val FILE = "zapten"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun getSecret(ctx: Context, key: String, def: String = ""): String {
        val p = prefs(ctx)
        val raw = p.getString(key, def) ?: def
        val out = Vault.open(raw)
        if (out.isNotEmpty() && !Vault.isSealed(raw)) {
            val sealed = Vault.seal(out)
            if (Vault.isSealed(sealed)) p.edit().putString(key, sealed).apply()
        }
        return out
    }

    private fun generateMac(rnd: java.security.SecureRandom): String {
        val tail = (1..3).joinToString(":") { "%02X".format(rnd.nextInt(256)) }
        return "00:1A:79:$tail"
    }

    /** Make portal N's MAC once (N = 1 or 2). A MAC the user already typed in is kept. */
    private fun ensureIdentity(ctx: Context, n: Int) {
        val p = prefs(ctx)
        val sfx = if (n == 2) "_2" else ""
        if (p.getBoolean("identity${sfx}_made", false)) return
        val rnd = java.security.SecureRandom()
        val existingMac = Vault.open(p.getString("mac$sfx", "") ?: "")
        p.edit()
            .putString("mac$sfx", Vault.seal(if (existingMac.isBlank()) generateMac(rnd) else existingMac))
            .putBoolean("identity${sfx}_made", true)
            .apply()
    }

    // ---- active portal (1 or 2) ----
    fun activePortal(ctx: Context) = prefs(ctx).getInt("active_portal", 1)
    fun saveActivePortal(ctx: Context, n: Int) = prefs(ctx).edit().putInt("active_portal", n).apply()

    // ---- portal URLs ----
    fun url(ctx: Context, n: Int = activePortal(ctx)): String =
        prefs(ctx).getString(if (n == 2) "url2" else "url", "") ?: ""
    fun saveUrl(ctx: Context, n: Int, v: String) =
        prefs(ctx).edit().putString(if (n == 2) "url2" else "url", v.trim()).apply()

    // ---- per-portal identity (generated on first touch) ----
    fun mac(ctx: Context, n: Int = activePortal(ctx)): String {
        ensureIdentity(ctx, n); return getSecret(ctx, if (n == 2) "mac_2" else "mac")
    }
    fun saveMac(ctx: Context, n: Int, v: String) =
        prefs(ctx).edit().putString(if (n == 2) "mac_2" else "mac", Vault.seal(v.trim().uppercase())).apply()
    /** The serial a box presents: upper(MD5(MAC))[0..13], derived from the MAC (no storage). */
    fun serial(ctx: Context, n: Int = activePortal(ctx)): String = BoxCrypto.macSerial(mac(ctx, n))
    /** The device id a box presents: upper(SHA-256(MAC)), the StbEmu/MAG derivation. */
    fun deviceId(ctx: Context, n: Int = activePortal(ctx)): String = BoxCrypto.macDeviceId(mac(ctx, n))
    /** device_id2 — a different value from device_id (build 4), also derived from the MAC. */
    fun deviceId2(ctx: Context, n: Int = activePortal(ctx)): String = BoxCrypto.macDeviceId2(mac(ctx, n))

    /** The adid tracking id a MAG keeps for its "adid" cookie: md5(mac + time), made once per portal. */
    fun adId(ctx: Context, n: Int = activePortal(ctx)): String {
        val key = if (n == 2) "adid_2" else "adid"
        val p = prefs(ctx)
        p.getString(key, null)?.takeIf { it.isNotBlank() }?.let { return it }
        val md = java.security.MessageDigest.getInstance("MD5")
            .digest((mac(ctx, n) + System.currentTimeMillis()).toByteArray(Charsets.UTF_8))
        val id = md.joinToString("") { "%02x".format(it) }
        p.edit().putString(key, id).apply()
        return id
    }

    // ---- the box's SaveUserData / LoadUserData store (access token etc.), keyed by the file name ----
    fun userData(ctx: Context, file: String): String =
        prefs(ctx).getString("ud_$file", "") ?: ""
    fun saveUserData(ctx: Context, file: String, data: String) =
        prefs(ctx).edit().putString("ud_$file", data).apply()

    // ---- first-run done ----
    fun setupDone(ctx: Context) = prefs(ctx).getBoolean("setup_done", false)
    fun markSetupDone(ctx: Context) = prefs(ctx).edit().putBoolean("setup_done", true).apply()
}
