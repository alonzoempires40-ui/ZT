plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.zapten.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zapten.app"
        minSdk = 28
        targetSdk = 34
        versionCode = 4
        versionName = "4.0"

        ndk {
            // Android TV / box: arm64 only (same as the StreamLine project the identity is shared with).
            abiFilters.add("arm64-v8a")
        }
    }

    signingConfigs {
        create("shared") {
            // The SAME debug keystore and alias as StreamLine, so the signing setup is identical
            // and proven on CI. The alias name is baked into the keystore binary — do not rename.
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "openstream"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Name the built APK after the version (ZapTen-v1.apk) instead of app-debug.apk.
    val builtVersionCode = defaultConfig.versionCode
    applicationVariants.all {
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName =
                "ZapTen-v${builtVersionCode}.apk"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    // androidx.webkit: WebViewCompat.addDocumentStartJavaScript — injects the set-top-box API
    // (window.gSTB …) before the portal's own scripts run, which is how a MAG box provides it.
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
