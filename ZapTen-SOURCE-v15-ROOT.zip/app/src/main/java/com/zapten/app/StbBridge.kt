package com.zapten.app

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * The set-top-box API, exposed to the portal's own c/ interface running in the WebView.
 *
 * A MAG box provides a native `gSTB` object; the portal's JavaScript calls it for the device
 * identity, the login crypto, device info and (later) the player. ZapTen provides the same object:
 * this class is injected as `ZTBridge`, and a small JS shim (injectionJs) builds `window.gSTB` and
 * the other box globals on top of it BEFORE the portal's scripts run. The portal then does the
 * handshake, get_profile and everything else itself, exactly as on a box.
 *
 * Identity + login + device info + the saved box environment (builds 1-5), and from build 6 the box
 * PLAYER API (Play/Stop/Pause/Continue/SetPosTime/GetPosTime/GetMediaLen/SetVolume/SetViewport/
 * SetPIG) handed to BoxPlayerHost — StreamLine's three engines behind the portal page.
 *
 * Methods run on the WebView's JavaScript-bridge thread, not the UI thread.
 */
class StbBridge(private val appCtx: Context, private val portal: Int,
                private val onReboot: () -> Unit = {},
                private val player: BoxPlayerHost? = null,
                private val onOpenWindow: (String) -> Unit = {},
                private val onCloseWindow: () -> Unit = {},
                private val onLoadUrl: (String) -> Unit = {},
                private val onProgress: (Int) -> Unit = {},
                private val onReady: () -> Unit = {},
                private val onTapNothing: () -> Unit = {},
                private val onKeyboard: (Boolean) -> Unit = {},
                private val onPortalEvent: (String) -> Unit = {}) {

    private val mac = BoxPrefs.mac(appCtx, portal)
    private val serial = BoxPrefs.serial(appCtx, portal)
    private val devId = BoxPrefs.deviceId(appCtx, portal).ifBlank { BoxCrypto.macDeviceId(mac) }
    private val devId2 = BoxPrefs.deviceId2(appCtx, portal)

    // ---- identity + login crypto (the portal's gSTB.GetUID / gSTB.GetHashVersion1 delegate here) ----

    /** GetUID() — the primary device id. */
    @JavascriptInterface fun deviceId(): String { DebugLog.add("gSTB.GetUID() -> device_id"); return devId }

    /** GetUID('device_id', token) — the second device id. Build 4: a DIFFERENT value from device_id
     *  (the portal rejected equal ids with "Invalid device (duplicate IDs)"). */
    @JavascriptInterface fun deviceId2(): String { DebugLog.add("gSTB.GetUID(device_id, token) -> device_id2"); return devId2 }

    /** GetUID(random) — the signature = Base64(HMAC-SHA256(key=random, data=device_id)) + "\n". */
    @JavascriptInterface fun sign(random: String): String { DebugLog.add("gSTB.GetUID(random) -> signature (random=" + random.take(8) + "…)"); return BoxCrypto.hmacB64(devId, random) }

    /** GetHashVersion1(a, b) — used for hw_version_2 (metrics, random) and prehash (model, ver56). */
    @JavascriptInterface fun hv1(a: String, b: String): String { DebugLog.add("gSTB.GetHashVersion1(" + (if (a.startsWith("{")) "metrics" else a.take(12)) + ", " + b.take(12) + "…)"); return BoxCrypto.getHashVersion1(a, b) }

    // ---- device info ----
    @JavascriptInterface fun mac(): String = mac
    @JavascriptInterface fun serial(): String = serial
    @JavascriptInterface fun model(): String = BoxCrypto.MODEL
    @JavascriptInterface fun hwVersion(): String = BoxCrypto.HW_VERSION
    @JavascriptInterface fun version(): String = "JS API version: 343; STB API version: 146; Player Engine version: 0x58c"

    /** RDir — the box's environment reader. The interface calls getenv/direct keys at start-up. */
    @JavascriptInterface
    fun rdir(arg: String): String {
        val a = arg.trim()
        DebugLog.add("gSTB.RDir(" + a + ")")
        if (a.startsWith("setenv ")) {
            // "setenv KEY VALUE" — a box writes this to flash. Keep it, so the next start reads it back.
            // (Build 5: the portal sets ntpurl then reboots; before, the value was dropped and the
            // interface stopped at the "reboot" — the black screen after a successful login.)
            val rest = a.substring(7).trim()
            val key = rest.substringBefore(' ').trim()
            val value = rest.substringAfter(' ', "").trim().trim('"')
            if (key.isNotEmpty()) { BoxPrefs.saveEnv(appCtx, portal, key, value); DebugLog.add("  env " + key + " = \"" + value + "\" saved") }
            return ""
        }
        val key = if (a.startsWith("getenv ")) a.substring(7).trim() else a
        BoxPrefs.env(appCtx, portal, key)?.let { return it }   // a value the portal set earlier wins (ntpurl, gmode…)
        return when (key) {
            "language" -> "en"
            "timezone_conf" -> "Europe/London"
            "ntpurl" -> "pool.ntp.org"
            "mtdparts" ->
                // two banks (contains "RootFs2") → num_banks = 2, matching the proven config
                "nand:0x00000000@0x00000000(\"RootFs\"),0x00000000@0x00000000(\"RootFs2\")"
            "update_url" -> ""
            // build 11: the box's video mode. Blank made the TV list's NOW WATCHING window lose its place
            // (the theme picks the window's position from it) and the channel played full screen behind
            "vmode" -> "720p-50"
            "gmode" -> "720"
            // build 11: what a MAG254 at 720p answers for the Settings pages' Video / Audio values
            "tvsystem" -> "720p-50"
            "graphicres" -> "1280"
            "audio_stereo_out_mode" -> "STEREO"
            "IPAddress" -> ""
            "MACAddress" -> mac
            "SerialNumber" -> serial
            "Model" -> BoxCrypto.MODEL
            "HardwareVersion" -> BoxCrypto.HW_VERSION
            "ImageVersion" -> BoxCrypto.IMAGE_VERSION
            "ImageDescription" -> BoxCrypto.IMAGE_DESCRIPTION
            "ImageDate" -> BoxCrypto.IMAGE_DATE
            "get_storage_info" -> "[]"          // build 8: no USB disks (the portal parses this as JSON)
            else -> ""
        }
    }

    // ---- build 11: GetEnv / SetEnv, the JSON form of RDir getenv / setenv the Settings pages use ----
    /** GetEnv('{"varList":["a","b"]}') → '{"result":{"a":"…","b":"…"},"errMsg":""}' (values as RDir gives them). */
    @JavascriptInterface
    fun getEnv(query: String): String {
        val res = org.json.JSONObject()
        runCatching {
            val list = org.json.JSONObject(query).optJSONArray("varList")
            if (list != null) for (i in 0 until list.length()) {
                val k = list.optString(i, "")
                if (k.isNotEmpty()) res.put(k, rdir(k))
            }
        }.onFailure { DebugLog.add("gSTB.GetEnv: not understood: " + query.take(120)) }
        return org.json.JSONObject().put("result", res).put("errMsg", "").toString()
    }
    /** SetEnv('{"a":"…","b":"…"}') or SetEnv(name, value) — kept, like the box keeps them in flash. */
    @JavascriptInterface
    fun setEnv(a: String, b: String): Boolean {
        val s = a.trim()
        if (s.startsWith("{")) {
            runCatching {
                val o = org.json.JSONObject(s)
                for (k in o.keys()) { val v = o.opt(k)?.toString() ?: ""; BoxPrefs.saveEnv(appCtx, portal, k, v); DebugLog.add("  env " + k + " = \"" + v + "\" saved") }
            }.onFailure { DebugLog.add("gSTB.SetEnv: not understood: " + s.take(120)) }
        } else if (s.isNotEmpty()) {
            BoxPrefs.saveEnv(appCtx, portal, s, b); DebugLog.add("  env " + s + " = \"" + b + "\" saved")
        }
        return true
    }

    // ---- the box PLAYER API (build 6) — the portal's player.js drives it; BoxPlayerState plays ----
    @JavascriptInterface fun play(uri: String, title: String) { player?.play(uri, title) }
    @JavascriptInterface fun stopPlay() { player?.stop() }
    @JavascriptInterface fun pausePlay() { DebugLog.add("gSTB.Pause()"); player?.pause() }
    @JavascriptInterface fun continuePlay() { DebugLog.add("gSTB.Continue()"); player?.resume() }
    @JavascriptInterface fun setPosTime(sec: Double) { DebugLog.add("gSTB.SetPosTime(" + sec.toLong() + ")"); player?.seekSec(sec.toLong()) }
    @JavascriptInterface fun getPosTime(): Long = player?.posSec() ?: 0
    @JavascriptInterface fun getMediaLen(): Long = player?.lenSec() ?: 0
    @JavascriptInterface fun isPlaying(): Boolean = player?.isPlaying() ?: false
    @JavascriptInterface fun setVolume(v: Double) { player?.setVolume(v.toInt()) }
    /** SetPIG(state, scale, x, y): scale < 0 → full screen; else a window scale×(1280×720) at x,y. */
    @JavascriptInterface fun setPig(state: Double, scale: Double, x: Double, y: Double) {
        DebugLog.add("gSTB.SetPIG(" + state.toInt() + ", " + scale + ", " + x.toInt() + ", " + y.toInt() + ")")
        if (scale <= 0) player?.setViewport(0, 0, 0, 0)
        else player?.setViewport(x.toInt(), y.toInt(), (1280 * scale).toInt(), (720 * scale).toInt())
    }
    /** SetViewport(w, h, x, y) in page pixels (1280×720 space). */
    @JavascriptInterface fun setViewport(w: Double, h: Double, x: Double, y: Double) {
        DebugLog.add("gSTB.SetViewport(" + w.toInt() + "x" + h.toInt() + " @" + x.toInt() + "," + y.toInt() + ")")
        player?.setViewport(x.toInt(), y.toInt(), w.toInt(), h.toInt())
    }
    // ---- build 10: FF/REW (stbPlayerManager.list[0].state), the APP menu's tracks, ASPECT ----
    @JavascriptInterface fun playerState(): Int = player?.playerState() ?: 0
    @JavascriptInterface fun audioPids(): String = player?.audioPidsJson() ?: "[]"
    @JavascriptInterface fun audioPid(): Int = player?.audioPid() ?: 0
    @JavascriptInterface fun setAudioPid(pid: Double) { DebugLog.add("gSTB.SetAudioPID(" + pid.toInt() + ")"); player?.setAudioPid(pid.toInt()) }
    @JavascriptInterface fun subtitlePids(): String = player?.subtitlePidsJson() ?: "[]"
    @JavascriptInterface fun subtitlePid(): Int = player?.subtitlePid() ?: -1
    @JavascriptInterface fun setSubtitlePid(pid: Double) { DebugLog.add("gSTB.SetSubtitlePID(" + pid.toInt() + ")"); player?.setSubtitlePid(pid.toInt()) }
    @JavascriptInterface fun setSubtitles(on: Boolean) { DebugLog.add("gSTB.SetSubtitles(" + on + ")"); player?.setSubtitles(on) }
    @JavascriptInterface fun setAspect(mode: Double) { DebugLog.add("gSTB.SetAspect(0x" + Integer.toHexString(mode.toInt()) + ")"); player?.setAspect(mode.toInt()) }

    /** ExecAction — the box's command runner. "reboot" restarts the portal page (a box restarts itself);
     *  "graphicres N" is remembered; everything else is logged and ignored. */
    @JavascriptInterface
    fun execAction(cmd: String) {
        val c = cmd.trim()
        DebugLog.add("gSTB.ExecAction(" + c + ")")
        when {
            c == "reboot" -> { DebugLog.add("  -> reboot: reloading the portal page"); onReboot() }
            c.startsWith("graphicres ") -> BoxPrefs.saveEnv(appCtx, portal, "gmode", c.substringAfter(' ').trim())
        }
    }

    /** SaveUserData(file, data) / LoadUserData(file) — the box's small key/value store (access token). */
    @JavascriptInterface fun saveUserData(file: String, data: String) { DebugLog.add("gSTB.SaveUserData(" + file + ")"); BoxPrefs.saveUserData(appCtx, file, data) }
    @JavascriptInterface fun loadUserData(file: String): String { DebugLog.add("gSTB.LoadUserData(" + file + ")"); return BoxPrefs.userData(appCtx, file) }

    // ---- build 8: the box's second browser window, the portal reload, loading state, touch ----
    /** stbWindowMgr.openWebFavorites / openWebWindow / LoadUrl — the portal's Settings page opens here. */
    @JavascriptInterface fun openWindow(url: String) { DebugLog.add("open window: " + url.take(160)); onOpenWindow(url) }
    /** stbWebWindow.close() — the page in the second window closes itself. */
    @JavascriptInterface fun closeWindow() { DebugLog.add("close window"); onCloseWindow() }
    /** gSTB.LoadURL(url) — a box loads that page in its browser (file:///home/web/… = the portal again). */
    @JavascriptInterface fun loadUrl(url: String) { DebugLog.add("gSTB.LoadURL(" + url.take(160) + ")"); onLoadUrl(url) }
    /** The portal's own loading bar position, 0-100. */
    @JavascriptInterface fun progress(pct: Double) { onProgress(pct.toInt().coerceIn(0, 100)) }
    /** The portal finished loading (its menu or start screen is up). */
    @JavascriptInterface fun ready() { DebugLog.add("portal ready"); onReady() }
    /** A tap on the page that hit no item (e.g. on the full-screen picture). */
    @JavascriptInterface fun tapNothing() { onTapNothing() }
    /** build 13: gSTB.ShowVirtualKeyboard / HideVirtualKeyboard — the box's keyboard, here Android's. */
    @JavascriptInterface fun showKeyboard(on: Boolean) { DebugLog.add("gSTB." + (if (on) "Show" else "Hide") + "VirtualKeyboard()"); onKeyboard(on) }
    /** build 14: gSTB.SendEventToPortal(json) — the Settings window's saved changes for the portal page
     *  (a MAG hands them to the portal as stbEvent.onPortalEvent). Only the size is logged: the message can
     *  carry the parental / settings password. */
    @JavascriptInterface fun sendEventToPortal(json: String) { DebugLog.add("gSTB.SendEventToPortal (" + json.length + " chars)"); onPortalEvent(json) }

    /** The injected JS reports here (gSTB installed, the login request/response, JS errors) so the
     *  on-screen log shows what happened even when the portal page stays black. */
    @JavascriptInterface fun log(line: String) = DebugLog.add("JS  $line")

    companion object {
        /** The User-Agent the WebView must send so the portal's load.php sees a MAG254. */
        fun userAgent(): String = BoxCrypto.USER_AGENT

        /**
         * The JS injected at document start, before the portal's own scripts. It builds window.gSTB
         * (delegating identity/crypto/info to ZTBridge) plus empty box globals, so the MAG interface
         * finds the box API it expects. gSTB is wrapped in a Proxy so any box method we have not wired
         * yet (the player etc.) is a harmless no-op instead of a crash — until build 2 fills them in.
         */
        fun injectionJs(): String = """
(function(){
  if (window.__ztGstb) { return; }
  window.__ztGstb = true;
  var B = window.ZTBridge;
  if (!B) { return; }
  B.log('shim installed at ' + location.href);
  // Full screen (build 6): the MAG interface lays itself out for the box's video mode, read from
  // screen.height (720 → the 1280×720 layout). Report a 1280×720 screen; the WebView is scaled to
  // fit the real display by ZapTen (setInitialScale), so the page fills the width of the screen.
  try {
    var ztScreen = { width: 1280, height: 720, availWidth: 1280, availHeight: 720 };
    for (var zk in ztScreen) { (function(kk, vv){ Object.defineProperty(window.screen, kk, { get: function(){ return vv; }, configurable: true }); })(zk, ztScreen[zk]); }
  } catch (e) { B.log('screen override failed: ' + e); }
  // The video plays BEHIND the page (like a MAG's video plane): the page background must be see-through.
  function ztCss(){
    if (document.getElementById('zt_css')) { return; }
    var st = document.createElement('style'); st.id = 'zt_css';
    st.textContent = 'html, body { background: transparent !important; }';
    (document.head || document.documentElement).appendChild(st);
    // fixed 1280-wide layout (the box's 720p mode); ZapTen scales it to the real screen width
    var mv = document.createElement('meta'); mv.name = 'viewport'; mv.content = 'width=1280';
    (document.head || document.documentElement).appendChild(mv);
  }
  if (document.documentElement) { ztCss(); }
  document.addEventListener('DOMContentLoaded', ztCss, false);
  window.addEventListener('error', function(e){ try { B.log('JS error: ' + e.message + ' @ ' + (e.filename||'') + ':' + e.lineno); } catch(x){} });
  // log every portal request the page makes (load.php type/action) and its answer size
  (function(){
    var open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(m, u){ this.__zt = String(u); return open.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function(){
      var x = this, u = x.__zt || '';
      var q = /[?&]type=([^&]*)&action=([^&]*)/.exec(u);
      var tag = q ? (q[1] + '/' + q[2]) : u.slice(0, 80);
      x.addEventListener('loadend', function(){
        var body = '';
        try { body = String(x.responseText || '').slice(0, 160).replace(/\s+/g, ' '); } catch(e){}
        try { B.log('xhr ' + tag + ' -> ' + x.status + ' ' + body); } catch(e){}
      });
      return send.apply(this, arguments);
    };
  })();

  // ---- build 13: a remote key the way a MAG's browser delivers it: to the element that has the focus
  // (it bubbles up to the page from there), with the key's name, as keydown + keypress + keyup, and a
  // digit / BACK typing into a text box (the PIN boxes of the adult categories are text boxes). Build 10
  // sent a bare keydown to the page body — a box listening on itself never heard it, and digits never typed.
  var ZT_KEYNAMES = { 8: ['Backspace', 'Backspace'], 9: ['Tab', 'Tab'], 13: ['Enter', 'Enter'], 27: ['Escape', 'Escape'],
    33: ['PageUp', 'PageUp'], 34: ['PageDown', 'PageDown'], 37: ['ArrowLeft', 'ArrowLeft'], 38: ['ArrowUp', 'ArrowUp'],
    39: ['ArrowRight', 'ArrowRight'], 40: ['ArrowDown', 'ArrowDown'], 107: ['+', 'NumpadAdd'], 109: ['-', 'NumpadSubtract'], 192: ['`', 'Backquote'] };
  var ztKeyInfo = function(code, shift){
    var n = ZT_KEYNAMES[code];
    if (n) { return { key: n[0], code: n[1], ch: n[0].length === 1 ? n[0] : '' }; }
    if (code >= 48 && code <= 57) { var d = String.fromCharCode(code); return { key: d, code: 'Digit' + d, ch: d }; }
    if (code >= 65 && code <= 90) { var L = String.fromCharCode(code), l = shift ? L : L.toLowerCase(); return { key: l, code: 'Key' + L, ch: l }; }
    if (code >= 112 && code <= 123) { return { key: 'F' + (code - 111), code: 'F' + (code - 111), ch: '' }; }
    return { key: 'Unidentified', code: '', ch: '' };
  };
  var ztIsTextBox = function(t){
    if (!t || t.nodeType !== 1 || t.disabled || t.readOnly) { return false; }
    return t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && /^(text|password|number|search|tel|email|url)$/i.test(t.type || 'text'));
  };
  var ztTypeInto = function(t, ch, del){
    var v = t.value || '', s = null, n = null;
    try { s = t.selectionStart; n = t.selectionEnd; } catch (x) {}
    if (s == null || n == null) { s = v.length; n = v.length; }
    if (del) { if (s === n && s > 0) { s--; } t.value = v.slice(0, s) + v.slice(n); }
    else { if (t.maxLength > 0 && v.length - (n - s) >= t.maxLength) { return; } t.value = v.slice(0, s) + ch + v.slice(n); s += ch.length; }
    try { t.setSelectionRange(s, s); } catch (x) {}
    t.dispatchEvent(new Event('input', { bubbles: true }));
  };
  window.__ztKey = function(code, shift, alt){
    shift = !!shift; alt = !!alt;
    var info = ztKeyInfo(code, shift);
    var t = document.activeElement;
    if (!t || t === document.documentElement || !document.documentElement.contains(t)) { t = document.body || document.documentElement; }
    var mk = function(type, kc, cc){
      var e = new KeyboardEvent(type, { bubbles: true, cancelable: true, view: window, key: info.key, code: info.code,
        shiftKey: shift, altKey: alt, keyCode: kc, which: kc, charCode: cc });
      try {
        Object.defineProperty(e, 'keyCode', { get: function(){ return kc; } });
        Object.defineProperty(e, 'which', { get: function(){ return kc; } });
        Object.defineProperty(e, 'charCode', { get: function(){ return cc; } });
      } catch (x) {}
      return e;
    };
    var go = t.dispatchEvent(mk('keydown', code, 0));
    var ch = alt ? '' : info.ch;
    if (go && (ch || code === 13)) { var pc = ch ? ch.charCodeAt(0) : 13; go = t.dispatchEvent(mk('keypress', pc, pc)); }
    if (go && !alt && (ch || code === 8) && ztIsTextBox(t)) { ztTypeInto(t, ch, code === 8); }
    t.dispatchEvent(mk('keyup', code, 0));
  };

  // build 10: the portal turns subtitles on/off by itself every time it reads the tracks (SetSubtitles
  // right before GetSubtitlePIDs) — that one is skipped, so StreamLine's auto-on stays; a choice made
  // in the APP menu (SetSubtitles on its own, or SetSubtitlePID) goes through.
  var ztSubCall = null;
  // build 11: a MAG draws its video ABOVE the page when the portal asks (SetTopWin(1)) — the TV list's
  // NOW WATCHING window does, inside its SetViewport window. ZapTen's video is behind the page, so the
  // page is cut away there and the picture shows through, as on the box (the theme's dark panel hid it).
  var ztTop = 0, ztWin = null;
  var ztHole = function(){
    if (window.top !== window || !document.body) { return; }
    var bd = document.body, r = ztWin;
    if (!ztTop || !r) { if (bd.style.clipPath || bd.style.webkitClipPath) { bd.style.clipPath = ''; bd.style.webkitClipPath = ''; } return; }
    var o = bd.getBoundingClientRect(), M = 20000;
    var x1 = r[0] - o.left, y1 = r[1] - o.top, x2 = x1 + r[2], y2 = y1 + r[3];
    var pts = [[-M,-M],[M,-M],[M,M],[-M,M],[-M,y1],[x1,y1],[x1,y2],[x2,y2],[x2,y1],[x1,y1],[-M,y1]];
    var cp = 'polygon(' + pts.map(function(q){ return q[0] + 'px ' + q[1] + 'px'; }).join(',') + ')';
    bd.style.webkitClipPath = cp; bd.style.clipPath = cp;
  };
  // The real box methods ZapTen implements for build 1 (identity, login crypto, device info, store).
  var real = {
    // GetUID(): device_id ; GetUID(random): signature ; GetUID(x, y[, z]): device_id2 (a different id)
    GetUID: function(){
      if (arguments.length === 0) { return B.deviceId(); }
      if (arguments.length === 1) { return B.sign(String(arguments[0])); }
      return B.deviceId2();
    },
    GetHashVersion1: function(a, b){ return B.hv1(String(a == null ? '' : a), String(b == null ? '' : b)); },
    GetDeviceMacAddress: function(){ return B.mac(); },
    GetDeviceSerialNumber: function(){ return B.serial(); },
    GetDeviceModelExt: function(){ return B.model(); },
    GetDeviceVersionHardware: function(){ return B.hwVersion(); },
    // build 11: the rest of Settings → Device info (blank before)
    GetDeviceModel: function(){ return B.model(); },
    GetDeviceVendor: function(){ return 'Infomir'; },
    GetDeviceActiveBank: function(){ return '0'; },
    GetDeviceImageVersion: function(){ return B.rdir('ImageVersion'); },
    GetDeviceImageDesc: function(){ return B.rdir('ImageDescription'); },
    GetDeviceImageVersionCurrent: function(){ return B.rdir('ImageDescription'); },
    GetHDMIConnectionState: function(){ return 1; },
    // build 8: a real MAG254 is not an emulator. As a function this was "true", which made the portal
    // swap its keys (Back acted as Exit) and hide most of the Settings page.
    IsEmulator: false,
    Version: function(){ return B.version(); },
    RDir: function(a){ return B.rdir(String(a == null ? '' : a)); },
    // build 11: the Settings pages read / write the box's values in JSON
    GetEnv: function(q){ return B.getEnv(typeof q === 'string' ? q : JSON.stringify(q || {})); },
    SetEnv: function(a, b){ return B.setEnv(typeof a === 'string' ? a : JSON.stringify(a || {}), b == null ? '' : String(b)); },
    SaveUserData: function(file, data){ B.saveUserData(String(file), String(data == null ? '' : data)); return true; },
    LoadUserData: function(file){ return B.loadUserData(String(file)); },
    // the box PLAYER (build 6) → ZapTen's BoxPlayerState → StreamLine's engines
    Play: function(uri){
      // build 10: with the portal's name for the item (StreamLine sends "Gr Subs" titles to VLC)
      var ztTitle = '';
      try { var ztItem = window.stb && stb.player && stb.player.cur_media_item; ztTitle = String((ztItem && ztItem.name) || ''); } catch (e) {}
      B.play(String(uri == null ? '' : uri), ztTitle);
    },
    Stop: function(){ B.stopPlay(); },
    Pause: function(){ B.pausePlay(); },
    Continue: function(){ B.continuePlay(); },
    SetPosTime: function(s){ B.setPosTime(Number(s) || 0); },
    GetPosTime: function(){ return B.getPosTime(); },
    GetMediaLen: function(){ return B.getMediaLen(); },
    IsPlaying: function(){ return B.isPlaying(); },
    SetVolume: function(v){ B.setVolume(Number(v) || 0); },
    SetPIG: function(st, sc, x, y){
      B.setPig(Number(st) || 0, Number(sc), Number(x) || 0, Number(y) || 0);
      ztWin = Number(sc) > 0 ? [Number(x) || 0, Number(y) || 0, 1280 * Number(sc), 720 * Number(sc)] : null; ztHole();
    },
    SetViewport: function(w, h, x, y){
      B.setViewport(Number(w) || 0, Number(h) || 0, Number(x) || 0, Number(y) || 0);
      ztWin = (Number(w) > 0 && Number(h) > 0) ? [Number(x) || 0, Number(y) || 0, Number(w), Number(h)] : null; ztHole();
    },
    SetTopWin: function(n){ ztTop = Number(n) ? 1 : 0; ztHole(); },
    SetLoop: function(){}, SetSpeed: function(){},
    // build 10: ASPECT → the picture on the tablet
    SetAspect: function(m){ B.setAspect(Number(m) || 0); },
    GetVolume: function(){ return 100; }, SetMute: function(){}, GetMute: function(){ return 0; },
    InitPlayer: function(){}, DeinitPlayer: function(){}, SetPlayerOption: function(){}, SetBufferSize: function(){},
    GetBufferLoad: function(){ return 100; }, SetSubtitlesEncoding: function(){},
    SetSubtitles: function(on){
      ztSubCall = !!on;
      setTimeout(function(){ if (ztSubCall !== null) { var v = ztSubCall; ztSubCall = null; B.setSubtitles(v); } }, 0);
    },
    SetSubtitlesSize: function(){}, SetSubtitlesFont: function(){}, SetSubtitlesColor: function(){},
    SetAudioLangs: function(){}, SetSubtitleLangs: function(){}, LoadExternalSubtitles: function(){},
    // build 10: the stream's real tracks (the APP menu's Audio and Subtitles)
    GetAudioPIDs: function(){ return B.audioPids(); }, GetAudioPIDsEx: function(){ return B.audioPids(); },
    GetAudioPID: function(){ return B.audioPid(); },
    SetAudioPID: function(p){ B.setAudioPid(Number(p) || 0); },
    GetSubtitlePIDs: function(){ ztSubCall = null; return B.subtitlePids(); },
    GetSubtitlePID: function(){ return B.subtitlePid(); },
    SetSubtitlePID: function(p){ ztSubCall = null; B.setSubtitlePid(Number(p) || 0); },
    GetVideoInfo: function(){ return '{}'; }, GetMetadataInfo: function(){ return '{}'; },
    // start-up no-ops (present so calls do not throw; harmless on a WebView)
    Debug: function(){}, ExecAction: function(a){ B.execAction(String(a == null ? '' : a)); }, StandBy: function(){}, StandByMode: function(){ return 0; },
    SetObjectCacheCapacities: function(){}, SetLedIndicatorMode: function(){}, SetLedIndicatorLevels: function(){},
    SetScreenSaverTime: function(){}, SetScreenSaverImplUrl: function(){}, SetScreenSaverInitAttr: function(){},
    SetSettingsInitAttr: function(){}, SetNetRcStatus: function(){}, ConfigNetRc: function(){},
    GetSystemPaths: function(){ return '{}'; },
    // build 8: answers the portal parses as JSON (an empty answer stopped the module loading)
    GetSmbGroups: function(){ return '{"result":[],"errMsg":""}'; },
    GetSmbServers: function(){ return '{"result":[],"errMsg":""}'; },
    GetSmbShares: function(){ return '{"result":[],"errMsg":""}'; },
    // build 8: "go to the portal again" from the settings page (file:///home/web/…) → reload
    LoadURL: function(u){ B.loadUrl(String(u == null ? '' : u)); },
    // build 13: the box's own keyboard — the portal asks for it when OK is pressed on a text box (the PIN
    // box) and on the remote's KB key; here Android's keyboard
    ShowVirtualKeyboard: function(){ B.showKeyboard(true); },
    HideVirtualKeyboard: function(){ B.showKeyboard(false); },
    // build 14: the Settings pages tell the running portal what they saved (Play in preview only by OK, the
    // parental PIN, …); a MAG hands it to the portal page as stbEvent.onPortalEvent — ZapTen does the same
    SendEventToPortal: function(s){ B.sendEventToPortal(typeof s === 'string' ? s : JSON.stringify(s == null ? {} : s)); }
  };

  // Wrap so any box method not listed above is a no-op (returns ''), and force the resize path to
  // use screen.height by making .prototype non-function.
  window.gSTB = new Proxy(real, {
    get: function(t, p){
      if (p === 'prototype') { return undefined; }
      // build 9: a MAG254 cannot start Android apps — without these the portal shows no
      // Applications tile (as on the owner's box); as no-op functions they made it appear
      if (p === 'startAplication' || p === 'appsList') { return undefined; }
      // build 10: no 3D on a tablet — the APP menu shows Audio, Subtitles, Claim, Video clock
      if (p === 'Set3DConversionMode' || p === 'Get3DConversionMode') { return undefined; }
      if (p in t) { return t[p]; }
      if (typeof p === 'symbol') { return t[p]; }
      return function(){ return ''; };
    }
  });

  // Other box globals the interface checks for / links to. Empty no-op objects for build 1;
  // build 8: a few methods answer what a MAG254 answers (see the objects passed in).
  function noop(defs){ return new Proxy(defs || {}, { get: function(t, p){
    if (p in t) { return t[p]; }
    if (typeof p === 'symbol') { return t[p]; }
    return function(){ return ''; };
  }}); }
  function ztEmpty(){ return '[]'; }
  function ztOpen(u){ B.openWindow(String(u == null ? '' : u)); }
  // build 8: the box's second browser window (the portal opens its Settings page in it) → ZapTen
  // opens that page full screen over the portal; the page's stbWebWindow.close() closes it again.
  window.stbWebWindow       = noop({ close: function(){ B.closeWindow(); } });
  window.stbWindowMgr       = noop({
    openWebFavorites: ztOpen, openWebWindow: ztOpen, LoadUrl: ztOpen,
    openWebFace: function(p){ var m = /[?&]url=([^&]*)/.exec(String(p)); if (m) { ztOpen(decodeURIComponent(m[1])); } else { B.log('openWebFace ' + p); } },
    InitWebWindow: function(){}, raiseWebWindow: function(){}
  });
  window.stbStorage         = noop();
  window.stbUpdate          = noop();
  window.stbDownloadManager = noop({ GetQueueInfo: ztEmpty });
  window.stbUPnP            = noop();
  // build 8: "no tuner" like a MAG254 — an empty answer here crashed the DVB/Settings modules and
  // stopped the portal loading every module after them (the missing Settings / Account info tiles)
  window.dvbManager         = noop({ GetSupportedScanTypes: ztEmpty, GetCurrentScanTypes: ztEmpty, GetChannelList: ztEmpty, GetEPGSchedule: ztEmpty });
  window.pvrManager         = noop({ GetAllTasks: ztEmpty });
  window.timeShift          = noop();
  window.stbEvent           = {};   // the interface ASSIGNS handlers onto this (onPortalEvent = …)
  // build 10: ◀◀ / ▶▶ read the player's state here (player.move_pos); without it they crashed
  window.stbPlayerManager   = noop({ list: [ { get state(){ return B.playerState(); } } ] });

  // ---- logging, so the on-screen panel shows what the portal actually did ----
  // Any script error on the portal page.
  window.addEventListener('error', function(e){
    try { B.log('PAGE ERROR ' + (e.message || '') + ' @' + (e.filename || '') + ':' + (e.lineno || '')); } catch(x){}
  });
  // The login traffic: log each server request's URL and the start of its response (this is where
  // "Authorization failed", a block message, or the token/profile shows up).
  try {
    var O = XMLHttpRequest.prototype.open, S = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(m, u){ this.__ztU = u; this.__ztM = m; return O.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function(){
      var x = this, u = String(x.__ztU || '');
      if (u.indexOf('load.php') >= 0 || u.indexOf('/server/') >= 0 || u.indexOf('portal.php') >= 0) {
        B.log('REQ ' + (x.__ztM || 'GET') + ' ' + u.slice(0, 160));
        x.addEventListener('load', function(){
          try { B.log('RESP ' + x.status + ' ' + String(x.responseText).slice(0, 220)); } catch(e){}
        });
        x.addEventListener('error', function(){ try { B.log('RESP ERROR (network) ' + u.slice(0, 120)); } catch(e){} });
      }
      return S.apply(this, arguments);
    };
  } catch(e){ B.log('xhr hook failed: ' + e); }

  // ---- build 8: loading progress + "the portal is up" (ZapTen shows its own loading screen until then) ----
  if (window.top === window) {
    var ztUp = false, ztPct = -1, ztPolls = 0;
    var ztPoll = setInterval(function(){
      ztPolls++;
      try {
        if (window.stb && stb.loader && typeof stb.loader.cur_pos === 'number') {
          var pct = Math.max(0, Math.min(100, Math.round(stb.loader.cur_pos)));
          if (pct !== ztPct) { ztPct = pct; B.progress(pct); }
        }
        var up = (window.main_menu && window.main_menu.on === true) ||
                 (window.stb && stb.loader && stb.loader.on === false && ztPct > 0);
        if (up && !ztUp) { ztUp = true; B.ready(); }
      } catch (e) {}
      if (ztUp || ztPolls > 400) { clearInterval(ztPoll); }
    }, 300);
  }

  // ---- build 8: touch like StreamLine. The MAG interface only listens to remote keys, so a tap
  // becomes the arrow presses that move the portal's own highlight onto what was tapped, then OK;
  // a swipe becomes arrow presses (finger up = Down). Works in every frame, so the Settings window's
  // pages (they also only follow keys) get it too; text boxes, buttons and links get the tap as it is.
  if (true) {
    var ZT_HL = /(^|[\s_-])(act|active)($|[\s_-])|_ring($|[\s_-])|(^|\s)sl_focus($|\s)/;
    var ztIds = 0, ztT = null, ZT_STEP = 64;
    var ztTouchCss = function(){
      if (document.getElementById('zt_touch_css')) { return; }
      var st = document.createElement('style'); st.id = 'zt_touch_css';
      st.textContent = 'html, body { -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; -webkit-tap-highlight-color: rgba(0,0,0,0); touch-action: none; }';
      (document.head || document.documentElement).appendChild(st);
    };
    if (document.documentElement) { ztTouchCss(); }
    document.addEventListener('DOMContentLoaded', ztTouchCss, false);
    // build 13: the same key delivery as the remote (to the focused element; it bubbles up, so the portal's
    // document listener and the Settings pages' <body onkeydown> both see it)
    var ztKey = function(code){ window.__ztKey(code, false, false); };
    var ztIsInput = function(el){
      for (var n = el, i = 0; n && n.nodeType === 1 && i < 4; n = n.parentElement, i++) {
        if (n.tagName === 'INPUT' || n.tagName === 'TEXTAREA' || n.tagName === 'SELECT' || n.tagName === 'BUTTON' || n.tagName === 'A' || n.isContentEditable) { return true; }
      }
      return false;
    };
    var ztNothing = function(){ if (window.top === window) { B.tapNothing(); } };
    // build 13: a box button that only reacts to the remote's OK (the PIN form's OK / Cancel have no click
    // action): a tap moves the form's focus onto it with ▼ / ▲, then presses OK — as on a MAG remote
    var ztOkOnly = function(el){
      return !!el && el.tagName === 'INPUT' && /^(button|submit)$/i.test(el.type || '') && !el.onclick && !el.getAttribute('onclick');
    };
    var ztPressOkOnly = function(el){
      for (var i = 0; i < 8 && document.activeElement !== el; i++) {
        var a = document.activeElement;
        var after = a && a !== document.body && (a.compareDocumentPosition(el) & 4);
        ztKey(after ? 40 : 38);
      }
      if (document.activeElement === el) { ztKey(13); }
    };
    // The portal's form that owns a button (its _items hold the buttons' inputs): choosing the button
    // there is exactly what the remote's OK does on it, whatever else is listening to the keys.
    var ztFormItem = function(el){
      var roots = [], k, r, i;
      try { if (window.module) { for (k in module) { roots.push(module[k]); } } } catch (x) {}
      try { roots.push(window.main_menu); } catch (x) {}
      try { roots.push(window.stb && stb.player); } catch (x) {}
      for (r = 0; r < roots.length; r++) {
        var o = roots[r];
        if (!o || typeof o !== 'object') { continue; }
        for (k in o) {
          var f;
          try { f = o[k]; } catch (x) { continue; }
          if (!f || typeof f !== 'object' || !f._items || !f._items.length) { continue; }
          for (i = 0; i < f._items.length; i++) { if (f._items[i] && f._items[i]._input_dom_odj === el) { return { form: f, idx: i }; } }
        }
      }
      return null;
    };
    var ztTapFormButton = function(el){
      var fi = ztFormItem(el);
      if (!fi) { ztPressOkOnly(el); return; }
      var f = fi.form, it = f._items[fi.idx];
      try { f._setPassiveItem && f._setPassiveItem(); } catch (x) {}
      f._cur_item_idx = fi.idx;
      try { f._setActiveItem && f._setActiveItem(); } catch (x) {}
      if (typeof it.action === 'function') { it.action(); } else { ztKey(13); }
    };

    // ---- build 9: a "‹ Back" button like the StreamLine theme's own (its .sl_v_hint: a blue pill
    // top left, 40 px, white), on every page of the portal except the main menu — not where the theme
    // shows its own Back, not over the full-screen picture — and on the Settings window's pages.
    // The page title beside it moves right to make room. Tap = Exit (on a MAG remote that is the key
    // that closes a page and goes back to the one before; Back alone means "previous channel" on TV).
    var ZT_BACK_WORDS = { en: '‹ Back', el: '‹ Πίσω', ru: '‹ Назад',
      uk: '‹ Назад', bg: '‹ Назад', de: '‹ Zurück',
      fr: '‹ Retour', it: '‹ Indietro', es: '‹ Atrás', tr: '‹ Geri' };
    var ztBackEl = null, ztShifted = [];
    var ztIsSettingsWin = function(){ return !!document.getElementById('zagolovok') && typeof window.pressKey === 'function'; };
    // build 14: the Settings window's tick boxes. A MAG's browser ticks / unticks a box when OK is pressed on
    // it; Android's does not (only Space does, and a remote has none), so "Play in preview only by OK" could
    // not be ticked and was saved as off. OK on the focused box, and a tap on the box drawn beside it (the
    // theme hides the real box and draws it as the picture of the label after it), tick / untick it.
    var ztInSettingsWin = function(){
      try { var w = window.top; return !!w.document.getElementById('zagolovok') && typeof w.pressKey === 'function'; } catch (x) { return false; }
    };
    var ztIsTick = function(el){ return !!el && el.tagName === 'INPUT' && /^checkbox$/i.test(el.type || '') && !el.disabled; };
    var ztTickOf = function(el){
      for (var n = el, i = 0; n && n.nodeType === 1 && i < 3; n = n.parentElement, i++) {
        if (n.tagName === 'LABEL') { var c = n.control || n.previousElementSibling; return ztIsTick(c) ? c : null; }
      }
      return null;
    };
    document.addEventListener('keydown', function(e){
      if (e.keyCode !== 13 || e.defaultPrevented || e.altKey || e.shiftKey) { return; }
      if (ztIsTick(e.target) && ztInSettingsWin()) { e.target.click(); }
    }, false);
    // build 15: a Settings page fills its tick box by first setting it empty ("true" compared with the portal's
    // yes / no value) and then asking for it ticked (the checked attribute). A MAG's browser ignores setting a
    // box to what it already is, so the ask ticks it; Android's counts it as set and then ignores the ask — the
    // box showed empty although the setting was on. In the Settings window, setting a tick box to what it
    // already is now changes nothing, as on a MAG.
    try {
      var ztChk = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'checked');
      if (ztChk && ztChk.get && ztChk.set) {
        Object.defineProperty(HTMLInputElement.prototype, 'checked', { configurable: true, enumerable: ztChk.enumerable, get: ztChk.get,
          set: function(v){ if (/^checkbox$/i.test(this.type || '') && !!v === ztChk.get.call(this) && ztInSettingsWin()) { return; } ztChk.set.call(this, v); } });
      }
    } catch (x) { B.log('tick box rule failed: ' + x); }
    var ztBackPress = function(){
      if (ztIsSettingsWin()) {
        // the Settings pages take their keys in the content frame; Exit goes back a page / closes
        var f = document.getElementById('cont'), d = null;
        try { d = f && f.contentDocument; } catch (x) { d = null; }
        var tw = (d && d.defaultView) || window, td = d || document;
        var e = new tw.KeyboardEvent('keydown', { bubbles: true, cancelable: true });
        Object.defineProperty(e, 'keyCode', { get: function(){ return 27; } });
        Object.defineProperty(e, 'which', { get: function(){ return 27; } });
        (td.body || td).dispatchEvent(e);
      } else {
        ztKey(27);
      }
    };
    var ztUnshift = function(){
      for (var i = 0; i < ztShifted.length; i++) { ztShifted[i].style.transform = ''; ztShifted[i].__ztShift = 0; }
      ztShifted = [];
    };
    var ztBackTick = function(){
      if (window.top !== window || !document.body) { return; }
      var portal = !!window.keydown_observer && !!window.main_menu, sw = ztIsSettingsWin();
      if (!portal && !sw) { return; }
      if (!ztBackEl) {
        ztBackEl = document.createElement('div'); ztBackEl.id = 'zt_back';
        ztBackEl.style.cssText = 'position:absolute;z-index:9000;display:none;height:40px;line-height:40px;padding:0 16px;' +
          '-webkit-border-radius:12px;border-radius:12px;background:-webkit-linear-gradient(left,#3a5bc0,#24357a);' +
          'background:linear-gradient(to right,#3a5bc0,#24357a);color:#ffffff;font-family:"SL SemiBold",sans-serif;' +
          'font-size:17px;white-space:nowrap;';
        document.body.appendChild(ztBackEl);
      }
      var show = sw, pageObj = null;
      if (portal) {
        var mm = window.main_menu, page = false, own = false;
        if (window.module) { for (var k in module) { var m = module[k]; if (m && m !== mm && m.on === true) { page = true; pageObj = m; break; } } }
        var hs = document.querySelectorAll('.sl_v_hint');
        for (var i = 0; i < hs.length; i++) { if (hs[i].offsetWidth > 0) { own = true; break; } }
        show = ztUp && mm.on !== true && page && !own;
      }
      if (!show) { if (ztBackEl.style.display !== 'none') { ztBackEl.style.display = 'none'; } ztUnshift(); return; }
      var lang = String((window.stb && stb.stb_lang) || 'en').substr(0, 2);
      var word = ZT_BACK_WORDS[lang] || ZT_BACK_WORDS.en;
      if (ztBackEl.textContent !== word) { ztBackEl.textContent = word; }
      ztBackEl.style.display = 'block';
      // the page's title: the open page's classic header (.mb_header_first — every page keeps its
      // own, so it is looked up inside the page that is on) or the Settings window's #zagolovok
      var hdr = null, cands = sw ? [document.getElementById('zagolovok')]
        : ((pageObj && pageObj.dom_obj && pageObj.dom_obj.querySelectorAll) ? pageObj.dom_obj.querySelectorAll('.mb_header_first') : []);
      for (var j = 0; j < cands.length; j++) {
        var c = cands[j];
        if (c && c.offsetWidth > 0 && c.getBoundingClientRect().top < 120 && getComputedStyle(c).visibility !== 'hidden') { hdr = c; break; }
      }
      for (var s = 0; s < ztShifted.length; s++) { if (ztShifted[s] !== hdr) { ztShifted[s].style.transform = ''; ztShifted[s].__ztShift = 0; } }
      ztShifted = hdr ? [hdr] : [];
      if (!hdr) { ztBackEl.style.left = '48px'; ztBackEl.style.top = '24px'; return; }
      var r = hdr.getBoundingClientRect(), left0 = r.left - (hdr.__ztShift || 0);
      var cl = Math.min(48, Math.max(12, Math.round(left0))), ct = Math.max(6, Math.round(r.top + r.height / 2 - 20));
      ztBackEl.style.left = cl + 'px'; ztBackEl.style.top = ct + 'px';
      var need = Math.max(0, Math.round(cl + ztBackEl.offsetWidth + 16 - left0));
      if (need !== (hdr.__ztShift || 0)) { hdr.style.transform = need ? 'translateX(' + need + 'px)' : ''; hdr.__ztShift = need; }
    };
    if (window.top === window) { setInterval(function(){ try { ztBackTick(); } catch (x) {} }, 300); }
    var ztVisible = function(el){
      var r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) { return null; }
      if (r.right < 0 || r.bottom < 0 || r.left > innerWidth || r.top > innerHeight) { return null; }
      var cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') { return null; }
      if (el.offsetParent === null && cs.position !== 'fixed') { return null; }
      return r;
    };
    var ztCommon = function(a, b){
      var anc = [];
      for (var n = a; n; n = n.parentNode) { anc.push(n); }
      for (var m = b; m; m = m.parentNode) { var i = anc.indexOf(m); if (i >= 0) { return anc.length - i; } }
      return 0;
    };
    // The portal's highlighted item nearest (in the page structure, then on screen) to the tapped one.
    var ztHighlight = function(el, x, y){
      var all = document.querySelectorAll('[class]'), best = null, bestD = -1, bestDist = 0;
      var big = innerWidth * innerHeight * 0.4;
      for (var i = 0; i < all.length; i++) {
        var c = all[i];
        if (c === document.body || c === document.documentElement) { continue; }
        var cn = typeof c.className === 'string' ? c.className : (c.getAttribute('class') || '');
        if (!ZT_HL.test(cn)) { continue; }
        var r = ztVisible(c);
        if (!r || r.width * r.height > big) { continue; }
        var d = ztCommon(el, c);
        var dist = Math.abs(r.left + r.width / 2 - x) + Math.abs(r.top + r.height / 2 - y);
        if (d > bestD || (d === bestD && dist < bestDist)) { best = c; bestD = d; bestDist = dist; }
      }
      return best;
    };
    var ztSig = function(h, el){
      if (!h.__ztId) { h.__ztId = ++ztIds; }
      var r = h.getBoundingClientRect(), t = el.getBoundingClientRect();
      return h.__ztId + ':' + Math.round(r.left) + ',' + Math.round(r.top) + ':' + Math.round(t.left) + ',' + Math.round(t.top);
    };
    var ztTap = function(x, y){
      // build 11: a tap on the video window (NOW WATCHING) = OK, as in the mockup: full screen
      if (window.top === window && ztTop && ztWin && x >= ztWin[0] && x <= ztWin[0] + ztWin[2] && y >= ztWin[1] && y <= ztWin[1] + ztWin[3]) { ztKey(13); return; }
      var el = document.elementFromPoint(x, y);
      if (!el || el === document.documentElement || el === document.body) { ztNothing(); return; }
      // the side tabs (left = Back / previous, right = next) and the colour-button bar
      for (var a = el, i = 0; a && a.nodeType === 1 && i < 10; a = a.parentElement, i++) {
        var c = typeof a.className === 'string' ? a.className : '';
        if (/(^|\s)ears_left/.test(c)) { ztKey(37); return; }
        if (/(^|\s)ears_right/.test(c)) { ztKey(39); return; }
        if (a.tagName === 'TD' && a.closest && a.closest('.color_button_bar')) { ztKey(112 + Math.max(0, Math.min(3, a.cellIndex))); return; }
      }
      // build 9: ZapTen's "‹ Back" button
      for (var bb = el, bi = 0; bb && bb.nodeType === 1 && bi < 4; bb = bb.parentElement, bi++) {
        if (bb.id === 'zt_back') { ztBackPress(); return; }
      }
      // build 14: a tick box of the Settings window (the picture beside the hidden box)
      var tk = ztTickOf(el);
      if (tk && ztInSettingsWin()) { tk.click(); return; }
      // build 13: the PIN form's OK / Cancel
      if (ztOkOnly(el)) { ztTapFormButton(el); return; }
      var h = ztHighlight(el, x, y);
      if (!h) { ztNothing(); return; }
      var hr = h.getBoundingClientRect(), t0 = el.getBoundingClientRect();
      if (!h.contains(el) && !el.contains(h) && t0.width * t0.height > 8 * hr.width * hr.height) { ztNothing(); return; }
      var ox = x - t0.left, oy = y - t0.top;
      for (var step = 0; step < 40; step++) {
        hr = h.getBoundingClientRect();
        var p = { x: x, y: y };
        if (document.documentElement.contains(el)) { var tr = el.getBoundingClientRect(); p = { x: tr.left + ox, y: tr.top + oy }; }
        if (h === el || h.contains(el) || (p.x >= hr.left && p.x <= hr.right && p.y >= hr.top && p.y <= hr.bottom)) { ztKey(13); return; }
        var dir = p.y > hr.bottom ? 40 : (p.y < hr.top ? 38 : (p.x > hr.right ? 39 : 37));
        var before = ztSig(h, el);
        ztKey(dir);
        var h2 = ztHighlight(el, p.x, p.y);
        if (!h2) { return; }
        if (ztSig(h2, el) === before) {
          var other = (dir === 38 || dir === 40) ? (p.x > hr.right ? 39 : (p.x < hr.left ? 37 : 0))
                                                 : (p.y > hr.bottom ? 40 : (p.y < hr.top ? 38 : 0));
          if (!other) { return; }
          ztKey(other);
          h2 = ztHighlight(el, p.x, p.y);
          if (!h2 || ztSig(h2, el) === before) { return; }
        }
        h = h2;
      }
    };
    document.addEventListener('touchstart', function(e){
      if (e.touches.length !== 1) { ztT = null; return; }
      var t = e.touches[0];
      ztT = { x: t.clientX, y: t.clientY, lx: t.clientX, ly: t.clientY, at: Date.now(), moved: false, axis: '',
              own: !ztIsInput(e.target) || ztOkOnly(e.target) };
    }, { capture: true, passive: true });
    document.addEventListener('touchmove', function(e){
      var s = ztT;
      if (!s || !s.own || e.touches.length !== 1) { return; }
      var t = e.touches[0];
      if (!s.moved && Math.abs(t.clientX - s.x) < 12 && Math.abs(t.clientY - s.y) < 12) { return; }
      s.moved = true;
      if (!s.axis) { s.axis = Math.abs(t.clientY - s.y) >= Math.abs(t.clientX - s.x) ? 'y' : 'x'; }
      if (s.axis === 'y') {
        while (t.clientY - s.ly <= -ZT_STEP) { ztKey(40); s.ly -= ZT_STEP; }
        while (t.clientY - s.ly >= ZT_STEP) { ztKey(38); s.ly += ZT_STEP; }
      } else {
        while (t.clientX - s.lx <= -ZT_STEP) { ztKey(39); s.lx -= ZT_STEP; }
        while (t.clientX - s.lx >= ZT_STEP) { ztKey(37); s.lx += ZT_STEP; }
      }
      if (e.cancelable) { e.preventDefault(); }
    }, { capture: true, passive: false });
    document.addEventListener('touchend', function(e){
      var s = ztT; ztT = null;
      if (!s || !s.own) { return; }
      if (e.cancelable) { e.preventDefault(); }
      if (s.moved || Date.now() - s.at > 800) { return; }
      try { ztTap(s.x, s.y); } catch (x) { B.log('tap failed: ' + x); }
    }, { capture: true, passive: false });
  }

  B.log('gSTB installed (model MAG254)');
})();
""".trimIndent()
    }
}
